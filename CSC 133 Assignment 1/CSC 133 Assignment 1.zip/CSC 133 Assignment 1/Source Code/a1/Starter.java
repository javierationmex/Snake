package a1;

public class Starter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Game g = new Game();

	}

}
