package a2.interfaces;

public interface IStrategy {
	public void apply();
}
