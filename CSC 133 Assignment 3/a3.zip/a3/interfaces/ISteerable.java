package a3.interfaces;

/**
 * @author Javier G
 * Interface to allow steering of an object in a certain direction
 */
public interface ISteerable {
	void turn(char direction);
	
}
