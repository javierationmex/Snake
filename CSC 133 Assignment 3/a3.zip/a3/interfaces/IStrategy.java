package a3.interfaces;

public interface IStrategy {
	public void apply();
}
