package a4.interfaces;

import java.awt.*;

/**
 * Created by Javier G on 11/23/2014.
 */
public interface IDrawable {

    public void draw(Graphics g);
}
