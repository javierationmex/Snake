package a4.interfaces;

public interface IStrategy {
	public void apply();
}
