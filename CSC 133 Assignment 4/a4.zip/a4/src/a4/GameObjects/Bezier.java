package a4.GameObjects;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.util.Random;

import a4.main.GameWorld;

public class Bezier extends Movable implements IDrawable, ICollider{
	
	private AffineTransform myTranslation, myRotation, myScale;
	private GameWorld gw;
	private int life;
	private boolean flag;
	Point2D[] Q;
	Point2D[] W;
	Point2D[] E;
	private Random rand;
	private int level;
	private float m,n;
	
	public Bezier(GameWorld GW, float d, float b){
		this.getLocation().setLocation(d, b);
		this.setSpeed(8);
		this.setHeading();
		this.setSize(100);
		gw=GW;
		myTranslation = new AffineTransform();
		myTranslation.translate(d, b);
	
		myRotation = new AffineTransform();
		myScale = new AffineTransform();
		life = 5000;
		level = 0;
		rand = new Random();
		
		
		Q = new Point2D [4];
		Q[0] = new Point2D.Double(rand.nextInt(150), rand.nextInt(150));
		Q[1] = new Point2D.Double(rand.nextInt(150), rand.nextInt(150));
		Q[2] = new Point2D.Double(rand.nextInt(150), rand.nextInt(150));
		Q[3] = new Point2D.Double(rand.nextInt(150), rand.nextInt(150));


		W = new Point2D [4];
		W[0] = new Point2D.Double(rand.nextInt(150), rand.nextInt(150));
		W[1] = new Point2D.Double(rand.nextInt(150), rand.nextInt(150));
		W[2] = new Point2D.Double(rand.nextInt(150), rand.nextInt(150));
		W[3] = new Point2D.Double(rand.nextInt(150), rand.nextInt(150));

		

		E = new Point2D [4];
		E[0] = new Point2D.Double(rand.nextInt(150), rand.nextInt(150));
		E[1] = new Point2D.Double(rand.nextInt(150), rand.nextInt(150));
		E[2] = new Point2D.Double(rand.nextInt(150), rand.nextInt(150));
		E[3] = new Point2D.Double(rand.nextInt(150), rand.nextInt(150));
		
		
	}
	
	 public void rotate (double degrees)
	 {
		 myRotation.rotate(Math.toRadians(degrees));
	 }
	 public void translate (double dx, double dy)
	 {
		 myTranslation.translate(dx, dy);
	 }
	 public void scale (double sx, double sy)
	 {
		 myScale.scale(sx, sy);
	 }
	 
	 public int getLifeTime()
	 {
		 return life;
	 }
	 
	 public void setLifeTime(int lifeTime)
	 {
		 this.life = lifeTime;
	 }
	 
	 
	 
	 public void setFlag(boolean b)
	 {
		 flag = b;
	 }
	 
	 public boolean getFlag()
	 {
		 return flag;
	 }
	@Override
	public boolean collidesWith(ICollider obj) {
		boolean result = false;
		
		//get centers of objects
		int curObjX = (int)this.getLocation().getXLocation() + (getSize()/2);
		int curObjY = (int)this.getLocation().getYLocation() + (getSize()/2);
		
		int othObjX = (int)((GameObject)obj).getLocation().getXLocation() + ((GameObject)obj).getSize()/2;
		int othObjY = (int)((GameObject)obj).getLocation().getYLocation() + ((GameObject)obj).getSize()/2;
		
		//get distance between objects
		int dx = curObjX - othObjX;
		int dy = curObjY - othObjY;
		int dist = (dx*dx + dy*dy);  //this is the distance
		
		//find square of radii
		int curObjR = getSize()/2;
		int othObjR = ((GameObject)obj).getSize()/2;
		int radSquared = (curObjR*curObjR + 2*curObjR*othObjR+
				othObjR*othObjR);
		if (dist <= radSquared)
		{result = true;
		
		}
		
		return result;
	}

	@Override
	public void handleCollision(ICollider obj) {
		if(obj instanceof Money)
		{
		gw.moneyDeath();
		
		}
		else if(obj instanceof Weasel)
		{
			gw.weaselDeath();
		}
		else if(obj instanceof Snake)
		{
			gw.deathByCollision();
		}
		else if(obj instanceof TotalBird)
		{
			
		}
	}

	@Override
	public void draw(Graphics2D g2d) {

		AffineTransform at = g2d.getTransform();
		g2d.transform(myTranslation);
		g2d.transform(myRotation);
		g2d.transform(myScale);
		
		for (int b = 0; b <=2; b++) // draw the bezier lines
		{
			Point2D p1 = Q[b];
			Point2D p2 = Q[b+1];
			g2d.setColor(Color.BLUE);
			g2d.drawLine( (int) p1.getX(), (int) p1.getY(), (int) p2.getX(), (int) p2.getY());
		}
		// draw the bezier curve
		g2d.setColor(Color.CYAN);
		drawBezierCurve(Q, g2d, level);
	
		g2d.setTransform(at);
		this.update();
	}
	public void drawBezierCurve(Point2D [] N, Graphics2D g2d, int Level)
	{
		int MaxLevel = 10;
		if (  (straightEnough(N) ) || (Level > MaxLevel) )
		{
			g2d.drawLine((int) N[0].getX(), (int) N[0].getY(), (int) N[3].getX(), (int) N[3].getY());
		}
		else {
			subdivideCurve(Q, W, E);
			drawBezierCurve(W, g2d, Level+1);
			drawBezierCurve(E, g2d, Level+1);
		}
	}
	
	void subdivideCurve (Point2D [] A, Point2D[] B, Point2D[] C)
	{
		double x, y;
		
		B[0] = A[0]; // R[0] = Q[0]
		x = ( A[0].getX() + A[1].getX() )/2;
		y = ( A[0].getY() + A[1].getY() )/2;
		B[1] = new Point2D.Double(x,y); // B(1) = (A(0)+A(1)) / 2.0 ;
		
		x = ( (B[1].getX() )/2) + ((A[1].getX()+A[2].getX() )/4);
		y = ( (B[1].getY())/2) + ((A[1].getY()+A[2].getY() )/4);
		B[2] = new Point2D.Double(x,y); //	B[2] = (B[1]/2.0) + (A[1]+A[2]/4.0)
		

		C[3] = A[3]; //	C[3] = A[3]
		
		x = ( A[2].getX() + A[3].getX() )/2;
		y = ( A[2].getY() + A[3].getY() )/2;
		C[2] = new Point2D.Double(x,y); //	C[2] = (A[2] + A[3])/2.0

		x = ( ((A[1].getX()+A[2].getX())/4) + ((C[2].getX())/2) );
		y = ( ((A[1].getY()+A[2].getY())/4) + ((C[2].getY())/2) );	
		C[1] = new Point2D.Double(x,y); //	C[1] = (A[1]+A[2])/4.0 + C[2]/2.0; 
		
		x = ( B[2].getX() + C[1].getX() )/2;
		y = ( B[2].getY() + C[1].getY() )/2;
		B[3] = new Point2D.Double(x,y); //	B[3] = (B[2]+C[1])/2.0 
		
		C[0] = B[3]; //	C[0] = B[3]
	} 
	
	boolean straightEnough(Point2D[] X)
	{
		boolean result;

		double d1 = lengthOf(X[0], X[1]) + lengthOf(X[1],X[2]) + lengthOf(X[2],X[3]);
		double d2 = lengthOf(X[0], X[3]);
		if (Math.abs(d1-d2) < .001)
		{
			result = true;
		}
		else
		{
			result = false;
		}
		return result;
	}
	public double lengthOf(Point2D A, Point2D B)
	{
		 double dx = A.getX() - B.getX();
		 double dy = A.getY() - B.getY();
		 double result = ( Math.sqrt(dx*dx + dy*dy) );
		 
		 return result; // return distance
	}
	@Override
	public void setStrategy(Strategy s) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void invokeStrategy() {
		// TODO Auto-generated method stub
		
	}
	
	public void move(){
		super.move();
		
	}
public void setHeading(){
		
		m = (float) ((((Math.random()*20)+1)-10)/10);
		n =  (float) ((((Math.random()*20)+1)-10)/10);
	}
	public void update(){
		myTranslation.translate(n*getSpeed(), m*getSpeed());
		
		this.getLocation().setLocation((float)myTranslation.getTranslateX(), (float)myTranslation.getTranslateY());
	}
}
