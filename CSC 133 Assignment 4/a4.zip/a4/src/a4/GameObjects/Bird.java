package a4.GameObjects;


import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.util.Random;

import a4.main.ISelectable;

/*
 * This program was designed by Daniel Baptista for CSC133
 * It has been finished on 10/15/2014
 */

public class Bird extends Movable implements IDrawable, ICollider, ISelectable{
	private int width;
	private int height;
	private boolean isSelected;
	private AffineTransform myTranslation, myRotation, myScale;
	/**
	* Bird constructor, performs setSize() in addition to the properties the bird gets
	*/
	public Bird(){
		setWidth();
		setHeight();
		this.getLocation().birdNest();
		myTranslation = new AffineTransform();
		myRotation = new AffineTransform();
		myScale = new AffineTransform();
		
	}
	
	public void rotate (double radians){
		myRotation.rotate(radians);
	
	}
	
	public void translate(double dx, double dy){
		myTranslation.translate(dx, dy);
	}
	
	public void scale(double sx, double sy){
		myScale.scale(sx, sy);
	}
	/**
	* setSize, this will take a number between 1 and 20 and choose it randomly for the bird size
	*/

	private void setWidth(){
		int minX = 45;
		int maxX = 60;
		Random rand = new Random();
		width = rand.nextInt((maxX - minX) + 1) + minX;	
	}
	
	private void setHeight(){
		int minX = 20;
		int maxX = 35;
		Random rand = new Random();
		height = rand.nextInt((maxX - minX) + 1) + minX;	
	}

	/**
	* size getter
	*/
	
	public int getHeight(){
		return height;
	}
	
	public int getWidth(){
		return width;
	}
	
	/**
	* String toString
	*/
	public String toString(){
		return "Bird:" + super.toString() + " size:" + getSize();
	
	}
	@Override
	public void setStrategy(Strategy s) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void invokeStrategy() {
		// TODO Auto-generated method stub
		
	}

	public void draw(Graphics2D g2d) {
		AffineTransform at = g2d.getTransform();
		g2d.setColor(Color.yellow);
		
		
		g2d.transform(myScale);
		g2d.transform(myTranslation);
		g2d.transform(myRotation);
		
		g2d.transform(at);
		g2d.fillOval((int)getLocation().getXLocation(), (int)getLocation().getYLocation(), getWidth(),getHeight());
		g2d.setTransform(at);
	//	g2d.rotate(Math.toRadians(getHeading()), 10, 10);
		//g2d.scale(1, -1);
		//g2d.translate(5, 5);
	
		/*
		if(isSelected()){
			g2d.setColor(Color.pink);
			
			
			g2d.transform(myScale);
			g2d.transform(myTranslation);
			g2d.transform(myRotation);
			
			g2d.transform(at);
			g2d.fillOval((int)getLocation().getXLocation(), (int)getLocation().getYLocation(), getWidth(),getHeight());
			g2d.setTransform(at);
		}
		else{
			g2d.setColor(Color.yellow);
			
			
			g2d.transform(myScale);
			g2d.transform(myTranslation);
			g2d.transform(myRotation);
			
			g2d.transform(at);
			g2d.fillOval((int)getLocation().getXLocation(), (int)getLocation().getYLocation(), getWidth(),getHeight());
			g2d.setTransform(at);
		}
		*/
		
	}

	@Override
	public boolean collidesWith(ICollider obj) {
		
		boolean result = false;
		
		//get centers of objects
		int curObjX = (int)this.getLocation().getXLocation() + (getSize()/2);
		int curObjY = (int)this.getLocation().getYLocation() + (getSize()/2);
		
		int othObjX = (int)((GameObject)obj).getLocation().getXLocation() + ((GameObject)obj).getSize()/2;
		int othObjY = (int)((GameObject)obj).getLocation().getYLocation() + ((GameObject)obj).getSize()/2;
		
		//get distance between objects
		int dx = curObjX - othObjX;
		int dy = curObjY - othObjY;
		int dist = (dx*dx + dy*dy);  //this is the distance
		
		//find square of radii
		int curObjR = getSize()/2;
		int othObjR = ((GameObject)obj).getSize()/2;
		int radSquared = (curObjR*curObjR + 2*curObjR*othObjR+
				othObjR*othObjR);
		if (dist <= radSquared)
		{result = true;
		
		}
		
		return result;	
		}

	

	@Override
	public void handleCollision(ICollider obj) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setSelected(boolean yesNo) {
		isSelected = yesNo;
		
	}

	@Override
	public boolean isSelected() {
		return isSelected;
	}

	@Override
	public boolean contains(Point2D p) {
		int px = (int)p.getX();
		int py = (int)p.getY();
		int xLoc = (int)this.getLocation().getXLocation();
		int yLoc = (int)this.getLocation().getYLocation();
		if( (px >= xLoc) && (px <= xLoc + getWidth())
				&& (py >= yLoc) && (py <= yLoc+getHeight()))
		return true;
		else return false;
	}


}

