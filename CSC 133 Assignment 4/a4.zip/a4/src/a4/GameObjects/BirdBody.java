package a4.GameObjects;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.AffineTransform;
import java.util.Random;


	
	
	public class BirdBody extends Movable{
		private int myRadius;
		private Color myColor ;
		private AffineTransform myTranslation ;
		private AffineTransform myRotation ;
		private AffineTransform myScale ;
		
		
		
		public BirdBody() {
		
		myRadius = 30; myColor = Color.yellow ;
		myTranslation = new AffineTransform();
		myRotation = new AffineTransform();
		myScale = new AffineTransform();
		
		
		}
		
		public void rotate (double radians){
			myRotation.rotate(radians);
		
		}
		
		public void translate(double dx, double dy){
			myTranslation.translate(dx, dy);
		}
		
		public void scale(double sx, double sy){
			myScale.scale(sx, sy);
		}
		
		
	
		// ...code here implementing rotate(), scale(), and translate() as in the Flame class
		public void draw (Graphics2D g2d) {
		AffineTransform saveAT = g2d.getTransform() ;
		g2d.transform(myTranslation);
		g2d.transform(myRotation);
		g2d.transform(myScale);
		g2d.setColor(myColor);
		
		// calculate the local-space location of the lower-left corner of the bounding box
		// for the circle, since that's where the object will be drawn from in local space
		Point boxCorner = new Point (-myRadius, -myRadius);
		g2d.fillOval (boxCorner.x, boxCorner.y, myRadius*2, myRadius*2) ;
		//g2d.fillOval (((int)boxCorner.getLocation().getX()), (int)boxCorner.getLocation().getY(), myRadius*2, myRadius*2) ;
		g2d.setTransform (saveAT) ;

}

		@Override
		public void setStrategy(Strategy s) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void invokeStrategy() {
			// TODO Auto-generated method stub
			
		}
	}
