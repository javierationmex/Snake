package a4.GameObjects;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.AffineTransform;

public class BirdWing implements IDrawable{
private Point top, bottomLeft, bottomRight;
	
	private AffineTransform myTranslation, myRotation, myScale;
	
	public BirdWing(){
		top = new Point (0, 3);
		bottomLeft = new Point(-3,-2);
		bottomRight = new Point (3, -2);
		
		myTranslation = new AffineTransform();
		myRotation = new AffineTransform();
		myScale = new AffineTransform();
		
	}
	
	public void rotate (double degrees){
		myRotation.rotate(Math.toRadians(degrees));
	
	}
	
	public void translate(double dx, double dy){
		myTranslation.translate(dx, dy);
	}
	
	public void scale(double sx, double sy){
		myScale.scale(sx, sy);
	}
	
	
	
	
	@Override
	public void draw(Graphics2D g2d) {
		
		AffineTransform saveAT = g2d.getTransform();
		
		
		g2d.transform(myRotation);
		g2d.transform(myScale);
		g2d.transform(myTranslation);
		
		g2d.setColor(Color.ORANGE);

		g2d.drawLine(top.x, top.y, bottomLeft.x, bottomLeft.y);
		g2d.drawLine(bottomLeft.x, bottomLeft.x, bottomRight.x, bottomRight.y);
		g2d.drawLine(bottomRight.x, bottomRight.y, top.x, top.y);
		
		g2d.setTransform(saveAT);
		
	}
}


