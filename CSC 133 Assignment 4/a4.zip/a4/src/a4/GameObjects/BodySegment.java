package a4.GameObjects;

import java.awt.geom.AffineTransform;

/*
 * This program was designed by Daniel Baptista for CSC133
 * It has been finished on 10/15/2014
 */



public class BodySegment extends Movable implements ICollider{
	private AffineTransform myTranslation ;
	private AffineTransform myRotation ;
	private AffineTransform myScale ;
	/**
	* Body segment constructor, takes location speed and heading as parameters
	*/
	public BodySegment(float d, float b, int j, int f) {
		this.getLocation().setLocation(d, b);
		myTranslation = new AffineTransform();
		myRotation = new AffineTransform();
		myScale = new AffineTransform();
		setSpeed(j);
		setHeading(f);
	}
	
	public void rotate (double radians){
		myRotation.rotate(radians);
	
	}
	
	public void translate(double dx, double dy){
		myTranslation.translate(dx, dy);
	}
	
	public void scale(double sx, double sy){
		myScale.scale(sx, sy);
	}



	/**
	* String toString
	*/
public String toString(){
	return "BodySegment: " + super.toString();
}





	@Override
	public void setStrategy(Strategy s) {
		// TODO Auto-generated method stub
		
	}





	@Override
	public void invokeStrategy() {
		// TODO Auto-generated method stub
		
	}





	@Override
	public boolean collidesWith(ICollider obj) {
		// TODO Auto-generated method stub
		return false;
	}





	@Override
	public void handleCollision(ICollider obj) {
		// TODO Auto-generated method stub
		
	}
}
		
