package a4.GameObjects;

import java.util.Random;

/*
 * This program was designed by Daniel Baptista for CSC133
 * It has been finished on 10/15/2014
 */



public abstract class Fixed extends GameObject{

private int age;
private int value;
/**
* setLocation with a parameter passed but it doesn't do anything. This prevents the program from having some 
* issues
*/
@Override
public void setLocation(Location x) {
	
	
	}

	
/**
* Age setter
*/
	public int setAge(){
		age = age + 1;
		
		return age;
	} 
	/**
	* Value setter, with passed ints.
	*/
	public void setValue(int param){
	
		int minX = 1;
		int maxX = param;
		
		
		
		Random rand = new Random();
		
		value = rand.nextInt( (maxX -minX) + 1) + minX;
	}
	/**
	* Value getter
	*/
	public int getValue(){
		return value;
	}
	/**
	* Age getter
	*/
	public int getAge(){
		return age;
	}
	/**
	* String toString
	*/
	public String toString(){
		return super.toString() + " age:" + getAge();
}
}

