package a4.GameObjects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;

import a4.main.ISelectable;

/*
 * This program was designed by Daniel Baptista for CSC133
 * It has been finished on 10/15/2014
 */

public class Food extends Fixed implements IDrawable, ICollider, ISelectable{
	private boolean isSelected;
	private AffineTransform myTranslation, myRotation, myScale;
	
	/**
	* Food constructor, sets the value between 1 and 10
	*/
	public Food(float x, float y){
		getLocation().setLocation(x, y);
		myTranslation = new AffineTransform();
		myTranslation.translate(x, y);
		myRotation = new AffineTransform();
		myScale = new AffineTransform();
		setValue(10);
		setSize(50);
		
	}
	
	public void rotate (double degrees){
		myRotation.rotate(Math.toRadians(degrees));
	
	}
	
	public void translate(double dx, double dy){
		myTranslation.translate(dx, dy);
	}
	
	public void scale(double sx, double sy){
		myScale.scale(sx, sy);
	}
	/**
	* String toString
	*/
	public String toString(){
		return "Food:" + super.toString() + " value:" + getValue();
	}
	@Override
	public void draw(Graphics2D g2d) {
		AffineTransform at = g2d.getTransform();
		g2d.transform(myTranslation);
		g2d.transform(myRotation);
		g2d.transform(myScale);
		
		//if(isSelected()){
			
		
		//	g2d.setColor(Color.pink);
		//	g2d.fillOval(0,0, this.getSize(), this.getSize());
			
	//	}
	//	else{
			
		
			g2d.setColor(Color.RED);
			g2d.fillOval(0, 0, this.getSize(), this.getSize());
			
	//	}
		g2d.setTransform(at);
	}
	@Override
	public boolean collidesWith(ICollider otherObject) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public void handleCollision(ICollider otherObject) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setSelected(boolean yesNo) {
		isSelected = yesNo;
		
	}

	@Override
	public boolean isSelected() {
		return isSelected;
	}

	@Override
	public boolean contains(Point2D p) {
		int px = (int)p.getX();
		int py = (int)p.getY();
		int xLoc = (int)this.getLocation().getXLocation();
		int yLoc = (int)this.getLocation().getYLocation();
		if( (px >= xLoc) && (px <= xLoc + getSize())
				&& (py >= yLoc) && (py <= yLoc+getSize()))
		return true;
		else return false;
	}
	
}
