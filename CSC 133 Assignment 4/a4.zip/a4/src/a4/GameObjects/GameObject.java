package a4.GameObjects;

import java.awt.Color;
import java.awt.geom.AffineTransform;
import java.util.Random;
/*
 * This program was designed by Daniel Baptista for CSC133
 * It has been finished on 10/15/2014
 */
//82900

public abstract class GameObject{
	


	private Location location;
	private int size;
	private AffineTransform myTranslate, myRotate, myScale;
	

/**
* GameObject constructor: provides set colors for wall/head and segment, random colors for the rest of objects.
*/
	public GameObject(){

		myTranslate = new AffineTransform();
		myRotate = new AffineTransform();
		myScale = new AffineTransform();
		location = new Location();
	
	}
	
	 public void rotate (double degrees)
	 {
		 myRotate.rotate(Math.toRadians(degrees));
	 }
	 public void translate (double dx, double dy)
	 {
		 myTranslate.translate(dx, dy);
	 }
	 public void scale (double sx, double sy)
	 {
		 myScale.scale(sx, sy);
	 }
	
	
	public void setLocation(Location x){
		location = x;
	}
	
	public void setSize(int x){
		size = x;
	}
	
	public int getSize(){
		return size;
	}
	

	 public AffineTransform getRotate()
		{
			return myRotate;
		}
		public AffineTransform getScale()
		{
			return myScale;
		}
		public AffineTransform getTranslate()
		{
			return myTranslate;
		}
/**
* Location Getter
*/
	public Location getLocation(){
		return location;
		
	}

/**
* Color Getter
*/
	//public Color getColor(){
		
	//	return color;
	//}
/**
* String toString
*/
	public String toString(){
		return "loc=" + getLocation().getXLocation() + " , " + getLocation().getYLocation();// +
				//" color= " + getColor().toString();
	}
}
