package a4.GameObjects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

import a4.main.GameWorld;

public class Head extends Movable implements iSteerable,IDrawable, ICollider{

	private GameWorld GW;
	private AffineTransform myTranslation ;
	private AffineTransform myRotation ;
	private AffineTransform myScale ;
	private int xs[] = {0, -10, 10};
	private int ys[] = {10, -10, -10};
	/**
	* Head constructor
	*/
	public Head(){
		
	}
	/**
	* Head constructor that takes a location, and 2 ints
	*/
	public Head(float d, float b, int h, int s, GameWorld GW){
	
		this.getLocation().setLocation(d, b);
	
		myTranslation = new AffineTransform();
		//myTranslation.translate(d, b);
		myRotation = new AffineTransform();
		myScale = new AffineTransform();
		setHeading(h);
		setSpeed(s);
		
	}
	
	public void rotate (double radians){
		myRotation.rotate(radians);
	
	}
	
	public void translate(double dx, double dy){
		myTranslation.translate(dx, dy);
	}
	
	public void scale(double sx, double sy){
		myScale.scale(sx, sy);
	}
	/**
	* Steerable has been added here
	*/
	@Override
public void steerable(int param) {
		
		if(param == 0){
			setHeading(0);
		}else if(param == 90){
			setHeading(90);
		}else if(param == 180){
			setHeading(180);
		}else if(param == 270){
			setHeading(270);
		}	
	
			
		}
	/**
	* String toString
	*/
	public String toString(){
		return "Snake head:" + super.toString();
	}
	@Override
	public void setStrategy(Strategy s) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void invokeStrategy() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void draw(Graphics2D g2d) {
		AffineTransform saveAT = g2d.getTransform() ;
		g2d.transform(myTranslation);
		g2d.transform(myRotation);
	g2d.transform(myScale);
		g2d.setColor(Color.green);
		g2d.drawPolygon(xs, ys, 3);
		g2d.setTransform (saveAT) ;
		
	}
	@Override
	public boolean collidesWith(ICollider obj) {
			
		boolean result = false;
		
		//get centers of objects
		int curObjX = (int)this.getLocation().getXLocation() + (getSize()/2);
		int curObjY = (int)this.getLocation().getYLocation() + (getSize()/2);
		
		int othObjX = (int)((GameObject)obj).getLocation().getXLocation() + ((GameObject)obj).getSize()/2;
		int othObjY = (int)((GameObject)obj).getLocation().getYLocation() + ((GameObject)obj).getSize()/2;
		
		//get distance between objects
		int dx = curObjX - othObjX;
		int dy = curObjY - othObjY;
		int dist = (dx*dx + dy*dy);  //this is the distance
		
		//find square of radii
		int curObjR = getSize()/2;
		int othObjR = ((GameObject)obj).getSize()/2;
		int radSquared = (curObjR*curObjR + 2*curObjR*othObjR+
				othObjR*othObjR);
		if (dist <= radSquared)
		{result = true;
		
		}
		
		return result;
		}
	@Override
	public void handleCollision(ICollider obj) {
		if(obj instanceof Snake){
			GW.animalCollision().play();
			GW.deathByCollision();
		}
		if(obj instanceof Head){
			System.out.println("How did you do that?");
		}
		
	}

	
	
}
