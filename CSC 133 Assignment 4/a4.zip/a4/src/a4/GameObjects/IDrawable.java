package a4.GameObjects;

import java.awt.Graphics;
import java.awt.Graphics2D;

public interface IDrawable {

	public void draw(Graphics2D g2d);
}
