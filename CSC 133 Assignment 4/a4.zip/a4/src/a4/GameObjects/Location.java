package a4.GameObjects;

import java.awt.geom.AffineTransform;
import java.util.Random;
/*
 * This program was designed by Daniel Baptista for CSC133
 * It has been finished on 10/15/2014
 */

public class Location {
	private float xLocation, yLocation;
	

/**
* Location constructor which sets a random location
*/
	public Location(){
		

	}

	
	 
	
	
	public void birdNest(){
		int spawn;
		Random rand = new Random();
		int minX = 0;
		int maxX = 4;
		
		spawn = rand.nextInt((maxX - minX) + 1) + minX;	
		
		if(spawn == 1){
			setLocation(250,250);
		} else if(spawn ==2){
			setLocation(750,750);
		} else if(spawn ==3){
			setLocation(250,750);
		} else if(spawn ==4){
			setLocation(750,250);
		}
		}
	
/**
* Location constructor with 2 passed parameters that you can use to set the location
*/	
	public Location(float x, float y){
		setLocation(x, y);
	}

/**
* xLocation getter
*/
	public float getXLocation(){
		return xLocation;
	}

/**
* yLocation getter
*/
	public float getYLocation(){
		return yLocation;
	}
	

/**
* setLocation that takes 2 parameters
*/
	public void setLocation(float x, float y){
		xLocation = x;
		yLocation = y;
	}


/**
* String toString
*/
	public String toString(){
		return "loc= " + getXLocation() + " , " + getYLocation();
	}
}
