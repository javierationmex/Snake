package a4.GameObjects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;

import a4.main.GameWorld;
import a4.main.ISelectable;


/*
 * This program was designed by Daniel Baptista for CSC133
 * It has been finished on 10/15/2014
 */



public class Money extends Fixed implements IDrawable, ICollider, ISelectable{
	private GameWorld gw;
	private boolean moneyFlag;
	private boolean isSelected;
	private boolean toDelete = false;
	private AffineTransform myTranslation, myRotation, myScale;
	
/**
* Money constructor, this will set the value between 1-100 using a method from Fixed
*/
	
	public Money(float x, float y){
		this.setValue(100);
		this.setSize(50);
		
		moneyFlag = false;
		myTranslation = new AffineTransform();
		myTranslation.translate(x, y);
		myRotation = new AffineTransform();
		myScale = new AffineTransform();
		this.getLocation().setLocation((float)myTranslation.getTranslateX(), (float)myTranslation.getTranslateY());
		
	}
	public void rotate (double degrees){
		myRotation.rotate(Math.toRadians(degrees));
	
	}
	
	public void shouldDelete(boolean yN) {
		toDelete = yN;	
		}
	
	public boolean getShouldDelete() {
		return toDelete;
	}
	
	public void translate(double dx, double dy){
		myTranslation.translate(dx, dy);
	}
	
	public void scale(double sx, double sy){
		myScale.scale(sx, sy);
	}
/**
* String toString
*/
	public String toString(){
		return "Money:" + super.toString() + " value:" + getValue();
	}




public void setFlag(boolean t){
	moneyFlag = t;
}


public boolean getFlag(){
	return moneyFlag;
}
@Override
public void draw(Graphics2D g2d) {
	AffineTransform at = g2d.getTransform();
	if(isSelected()){
		g2d.transform(myTranslation);
		g2d.transform(myRotation);
		g2d.transform(myScale);
		g2d.setColor(Color.pink);
		g2d.fillOval(0, 0, this.getSize(), this.getSize());
	
	}
	else{
		g2d.transform(myTranslation);
		g2d.transform(myRotation);
		g2d.transform(myScale);
		
		g2d.setColor(Color.BLUE);
		g2d.drawOval(0,0, this.getSize(), this.getSize());
		
	}
	g2d.setTransform(at);
	
}

@Override
public boolean collidesWith(ICollider obj) {
	boolean result = false;
	
	//get centers of objects
	
	int curObjX = (int)this.getLocation().getXLocation() + (getSize()/2);
	int curObjY = (int)this.getLocation().getYLocation() + (getSize()/2);
	
	
	//int curObjY = (int)this.getLocation().getYLocation() + (getSize()/2);
	
	int othObjX = (int)((GameObject)obj).getLocation().getXLocation() + ((GameObject)obj).getSize()/2;
	int othObjY = (int)((GameObject)obj).getLocation().getYLocation() + ((GameObject)obj).getSize()/2;
	
	//get distance between objects
	int dx = curObjX - othObjX;
	int dy = curObjY - othObjY;
	int dist = (dx*dx + dy*dy);  //this is the distance
	
	//find square of radii
	int curObjR = getSize()/2;
	int othObjR = ((GameObject)obj).getSize()/2;
	int radSquared = (curObjR*curObjR + 2*curObjR*othObjR+
			othObjR*othObjR);
	if (dist <= radSquared)
	{result = true;
	
	}
	
	return result;
	
}

@Override
public void handleCollision(ICollider obj) {
	

	
}

@Override
public void setSelected(boolean yesNo) {
	isSelected = yesNo;
	
}

@Override
public boolean isSelected() {
	return isSelected;
}

@Override
public boolean contains(Point2D p) {
	int px = (int)p.getX();
	int py = (int)p.getY();
	int xLoc = (int)this.getLocation().getXLocation();
	int yLoc = (int)this.getLocation().getYLocation();
	if( (px >= xLoc) && (px <= xLoc + getSize())
			&& (py >= yLoc) && (py <= yLoc+getSize()))
	return true;
	else return false;
}


	
}
