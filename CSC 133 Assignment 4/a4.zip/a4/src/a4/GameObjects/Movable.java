package a4.GameObjects;
import java.awt.Graphics;
import java.awt.geom.AffineTransform;
import java.util.Random;


/*
 * This program was designed by Daniel Baptista for CSC133
 * It has been finished on 10/15/2014
 */



public abstract class Movable extends GameObject{

	private int heading;
	private int speed;
	private 	double deltaX, deltaY;
	protected Strategy curStrategy;
	abstract public void setStrategy(Strategy s);
	abstract public void invokeStrategy();


/**
* Movable constructor: Setspeed of objects and if the object is a bird it will give the bird its special
* heading and if not it will set the compass heading of the snake.
*/
	public Movable(){
		setSpeed();
		
		if(this instanceof Bird)
		setBirdHeading();
		else if(this instanceof TotalBird)
			setBirdHeading();
		else if(this instanceof Weasel)
		setBirdHeading();
		else setCompassHeading();
	}
	
	

/**
* the move location using the code from clevenger and accounting for the 90 degree adjustment.
*/
	public  void move(){
	
		Location temp = getLocation();
	/*
		setLocation(new Location(temp.getXLocation() + (int)(Math.cos(Math.toRadians(90-getHeading()))*(1000/60)), 
				temp.getYLocation() + (int)(Math.sin(Math.toRadians(90-getHeading()))*(1000/60))));
		*/
		setLocation(new Location(temp.getXLocation() + (int)(Math.cos(Math.toRadians(90-getHeading()))*(1000/60)), 
				temp.getYLocation() + (int)(Math.sin(Math.toRadians(90-getHeading()))*(1000/60))));
	}
/**
* This sets the bird heading with a random number from 1 - 360
*/
	private void setBirdHeading() {
	
		float minX = 1;
		float maxX = 360;
	
	
	
		Random rand = new Random();
	
		heading = (int) (rand.nextFloat() * (maxX -minX) + minX);

	}

/**
* Random Speed setter
*/
	public void setSpeed(){
		
		
		speed = new Random().nextInt(3) + 2;
		
	}
	
	public void bezSpeed(){
		speed = new Random().nextInt(10) + 2;
	}

/**
* Speed setter with a passed parameter
*/
	public void setSpeed(int s){
		
		speed = s;
	}
	

/**
* Set the heading of the snake
*/	
private void setCompassHeading(){
	
	heading = 0;
	
}


/**
* Set heading with a passed int, this is mainly used for the snake body segments
*/
public void setHeading(int x){
	heading = x;
}
//TEST ADDED

/**
* Heading getter
*/ 
public int getHeading(){
	 return heading;
 }

/**
* Speed getter
*/
 public int getSpeed(){
	 return speed;
 }

/**
* String toString
*/
 public String toString(){
		return super.toString() + " speed=" + getSpeed() + " heading=" + getHeading();
 }

}
