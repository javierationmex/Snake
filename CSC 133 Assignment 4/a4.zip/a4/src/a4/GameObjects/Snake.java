package a4.GameObjects;


import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;

import a4.main.GameWorld;

public class Snake extends Movable implements iSteerable, IDrawable, ICollider{
	
	private Head head;	
	private int newSegCount;
	private ArrayList<BodySegment> list;
	private GameWorld gw;
	private AffineTransform myTranslation, myRotation, myScale;
	private int xs[] = {0, -10, 10};
	private int ys[] = {10, -10, -10};
	//snake actual translation location is not being shown
/**
* Snake constructor: First, this will create the snake head with 3 parameters that are taken from the snake 
* object itself. Next the array list is setup, then we create headloc to get the headlocation. Next I get the
* x and y location of headloc which is then followed by me collecting the head speed and head heading. Finally
* I start off with headloc = new Location(x, y-3)
* this will place the last piece of the body 3 spaces away from the head.
* NOTE: I could have multiplied the subtracted pieces by speed to spread the snake out more but I didn't think 
* that was necessary. 
*/
	public Snake(GameWorld GW, float d, float b){
		myTranslation = new AffineTransform();
		myTranslation.translate(d, b);

		
		myRotation = new AffineTransform();
		myScale = new AffineTransform();
		setSize(15);
		gw = GW;
		head = new Head((int)d, (int)b, this.getHeading(), this.getSpeed(), GW);
		//this.getLocation().setLocation((float)myTranslation.getTranslateX(), (float)myTranslation.getTranslateY());
		int headX = (int)head.getLocation().getXLocation();
		
		int headY = (int)head.getLocation().getYLocation();
		
		;
		int headspe = head.getSpeed();
		
		int headhe = head.getHeading();
		list = new ArrayList<BodySegment>();
		
		list.add(new BodySegment(headX, headY, headspe, headhe));
		list.add(new BodySegment(headX, headY, headspe, headhe));
		list.add(new BodySegment(headX, headY, headspe, headhe));
	
	}
	public Rectangle getBounds(){
		return new Rectangle((int)this.rGetLocationX(),(int)this.rGetLocationY(),head.getSize(),head.getSize());
	}

	public float rGetLocationX(){
		return (float)myTranslation.getTranslateX();
		}
		public float rGetLocationY(){
			return (float)myTranslation.getTranslateY();
		}
	public void rotate (double radians){
		myRotation.rotate(radians);
	
	}
	
	public void translate(double dx, double dy){
		myTranslation.translate(dx, dy);
	}
	
	public void scale(double sx, double sy){
		myScale.scale(sx, sy);
	}

/**
* Steerable that has an effect on the head
* this will also prevent you from going back over the snakes body
*/
	public void steerable(int param) {
		
	
		if(param == 0){
			if(head.getHeading()==180){
				head.setHeading(180);
				setHeading(180);
			}else{
			head.setHeading(0);
			setHeading(0);
			}
		}
		else if(param == 90){
			if(head.getHeading()==270){
				head.setHeading(270);
				setHeading(270);
			}else{
			head.setHeading(90);
			setHeading(90);
			}
		}
		else if(param == 180){
			if(head.getHeading()==0){
				head.setHeading(0);
				setHeading(0);
			}else{
			head.setHeading(180);
			setHeading(180);
			}
		}
		else if(param == 270){
			if(head.getHeading()==90){
				head.setHeading(90);
				setHeading(90);
			}else{
			setHeading(270);
			head.setHeading(270);
			}
		} 
	}
//take the translate off the head
/**
* Override the move for the snake here, I call super to get the other parts of move. Next I  set up temp, tmp 
* and hehe in order to get location, speed and heading. I call head.move(); and go into an If statement.
* Each time tick() happens this if statement will happen one time, this if statement will check for if food
* has been consumed or not. If food has been consumed then we will continue to move but just add pieces in at 
* the heads last location. If food has not been consumed we will simply move the back to the insert point of
* the snake.
*/		
	@Override
	public void move() {
		super.move();
	
	/*	System.out.println("snake loc = " + head.getLocation());
		System.out.println("snake trans = " + myTranslation.getTranslateX()
				+ ", " + myTranslation.getTranslateY());
*/
		
		int headX = (int)head.getLocation().getXLocation();
		int headY = (int)head.getLocation().getYLocation();
		int tmp = head.getSpeed();
		int hehe = head.getHeading();

		head.move();
		
		
		if(newSegCount > 0){
		
			list.add(new BodySegment(headX,headY, tmp, hehe));
			newSegCount--;
		}
		else{
		list.get(0).getLocation().setLocation(headX, headY);
		
		list.get(0).setSpeed(tmp);
		list.get(0).setHeading(hehe);
		list.add(list.remove(0));
			
		}
		//working here
		bodyCollision();
		update();
	}
	

/**
* Setter for new segCount
*/
	public void setNewSegCount(int x){
		newSegCount = (x);
	}
	
public void update(){
	this.getLocation().setLocation((float)myTranslation.getTranslateX(), (float)myTranslation.getTranslateY());

}
/**
* String toString
*/
	public String toString(){
		String tmp = "";
		for(int i = list.size()-1; i>=1; i--)
			tmp = tmp + list.get(i).toString() + "\n";
			tmp = tmp + list.get(0).toString();
			return head.toString() + "\n" + tmp;
	}

/*
 * returns the snake heads location
 */
public Location getHeadLoc(){
	return (head.getLocation());
}

@Override
public void setStrategy(Strategy s) {
	// TODO Auto-generated method stub
	
}



@Override
public void invokeStrategy() {
	// TODO Auto-generated method stub
	
}
//in relation to headlocation is where we want to draw the body segments
//so if it's going left, x is decreasing and the body segments are + x so basically always the opposite of headlocations value


@Override
public void draw(Graphics2D g2d) {
	AffineTransform at = g2d.getTransform();
	g2d.transform(myScale);
	g2d.transform(myTranslation);
	g2d.transform(myRotation);
	
	
	
	if(head.getHeading()==0){
			int x[] = {(int)head.getLocation().getXLocation()-(getSize()/2),
			(int)head.getLocation().getXLocation()+(getSize()/2),
			(int)head.getLocation().getXLocation()};
	
	int y[] = {(int)head.getLocation().getYLocation()-(getSize()/2),
			(int)head.getLocation().getYLocation()-(getSize()/2),
			(int)head.getLocation().getYLocation()+(getSize()/2)
	};
	
	g2d.setColor(Color.GREEN);
	
	g2d.fillPolygon(x, y, 3);
	g2d.setTransform(at);
	
	}
	
	
	else if(head.getHeading() ==90){
		int x[] = {(int)head.getLocation().getXLocation()-(getSize()/2),
				(int)head.getLocation().getXLocation()-(getSize()/2),
				(int)head.getLocation().getXLocation()+(getSize()/2)};
		
		int y[] = {(int)head.getLocation().getYLocation()+(getSize()/2),
				(int)head.getLocation().getYLocation()-(getSize()/2),
				(int)head.getLocation().getYLocation()
		};
		g2d.setColor(Color.GREEN);
		
		g2d.fillPolygon(x, y, 3);
		g2d.setTransform(at);}
	else if(head.getHeading() ==180){
		int x[] = {(int)head.getLocation().getXLocation()-(getSize()/2),
				(int)head.getLocation().getXLocation()+(getSize()/2),
				(int)head.getLocation().getXLocation()};
		
		int y[] = {(int)head.getLocation().getYLocation()+(getSize()/2),
				(int)head.getLocation().getYLocation()+(getSize()/2),
				(int)head.getLocation().getYLocation()-(getSize()/2)
		};
		g2d.setColor(Color.GREEN);
	
		g2d.fillPolygon(x, y, 3);
		g2d.setTransform(at);}
	else if(head.getHeading() ==270){
		int x[] = {(int)head.getLocation().getXLocation()+(getSize()/2),
				(int)head.getLocation().getXLocation()+(getSize()/2),
				(int)head.getLocation().getXLocation()-(getSize()/2)};
		
		int y[] = {(int)head.getLocation().getYLocation()+(getSize()/2),
				(int)head.getLocation().getYLocation()-(getSize()/2),
				(int)head.getLocation().getYLocation()
		};
		g2d.setColor(Color.GREEN);
		
	
		g2d.fillPolygon(x, y, 3);
		g2d.setTransform(at);}
	
	/*
	 * 
	 */
	
	

	g2d.setColor(Color.green);

	for(int i = 0; i < list.size(); i++){
		
		g2d.fillRect((int)list.get(i).getLocation().getXLocation()-(getSize()/2), (int)list.get(i).getLocation().getYLocation()-(getSize()/2), getSize(), getSize());
		}
	g2d.setTransform(at);
}

public void bodyCollision(){

	int R1 = (int) (head.getLocation().getXLocation());
	int L1 = (int) (head.getLocation().getXLocation());
	int T1 = (int) (head.getLocation().getYLocation());
	int B1 = (int) (head.getLocation().getYLocation());
	
	for(int i = list.size()-1; i>=1; i--){
	
		
		int T2 = (int)list.get(i).getLocation().getYLocation()-4;
		int R2 = (int)list.get(i).getLocation().getXLocation()+2;
		int B2 = (int)list.get(i).getLocation().getYLocation()+2;
		int L2 = (int)list.get(i).getLocation().getXLocation()-2;
		
		boolean lrOverlap = (R1 > L2) && (L1 < R2);
		boolean tbOverlap = (B1 > T2) && (B2 > T1);
		
		if (lrOverlap && tbOverlap) {
			gw.deathByCollision();
		}
		
	}
	
}



@Override
public boolean collidesWith(ICollider obj) {
	
boolean result = false;
	

	//get centers of objects

	int curObjX = (int)head.getLocation().getXLocation() + (getSize()/2);
	int curObjY = (int)head.getLocation().getYLocation() + (getSize()/2);
	
	int othObjX = (int)((GameObject)obj).getLocation().getXLocation() + ((GameObject)obj).getSize()/2;
	int othObjY = (int)((GameObject)obj).getLocation().getYLocation() + ((GameObject)obj).getSize()/2;
	
	//get distance between objects
	int dx = curObjX - othObjX;
	int dy = curObjY - othObjY;
	int dist = (dx*dx + dy*dy);  //this is the distance
	
	//find square of radii
	int curObjR = getSize()/2;
	int othObjR = ((GameObject)obj).getSize()/2;
	int radSquared = (curObjR*curObjR + 2*curObjR*othObjR+
			othObjR*othObjR);
	if (dist <= radSquared)
	{result = true;
	
	}
	

	return result;
	
	
	}



@Override
public void handleCollision(ICollider obj) {
	if(obj instanceof Money)
	{
		if(gw.getBSound() ==true){
			gw.moneyGot().play();
			gw.moneyCollision();}
		else{
		gw.moneyCollision();
		
		}
	}
	
	else if(obj instanceof Food)
	{

		if(gw.getBSound() == true){
			 gw.eatFood().play(); 
			 gw.foodCollision();}
		 else {
			 gw.foodCollision();
		 }
	
	}

	else if(obj instanceof Weasel)
	{
		if(gw.getBSound()==true){
		gw.animalCollision().play();
		gw.deathByCollision();} 
		else{
		gw.deathByCollision();
		}
	}
	
	else if(obj instanceof Bird)
	{
		if(gw.getBSound()==true){
		gw.animalCollision().play();
		gw.deathByCollision();} 
		else {
		gw.deathByCollision();
		}
	}
	

	else if(obj instanceof Bezier)
	{
		if(gw.getBSound()==true){
			gw.animalCollision().play();
			gw.deathByCollision();
		}
		else {
			gw.deathByCollision();
		}
	}
	
	
}

public double getTranslateX() {
	/*return myTranslation.getTranslateX();*/
	return getLocation().getXLocation();
}

public double getTranslateY() {
	/*return myTranslation.getTranslateY();*/
	return getLocation().getYLocation();
}

}
