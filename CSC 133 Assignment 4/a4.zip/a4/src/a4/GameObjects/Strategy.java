package a4.GameObjects;
/**
 * Interface for Strategy
 * 
 *
 */
public interface Strategy {
	public void apply();
}
