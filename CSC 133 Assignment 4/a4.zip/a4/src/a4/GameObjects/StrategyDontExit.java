package a4.GameObjects;


import a4.GameObjects.Location;

public class StrategyDontExit implements Strategy {

	private Weasel client;
	

	/**
	 * Cons for sDE
	 * @param client the weasel
	 * @param x Location
	 * @param j Heading
	 */
	public StrategyDontExit(Weasel client, Location x, int j){
		
		
		this.client = client;
		
		client.getLocation();
		client.getHeading();
		this.apply();
		
	}

	/**
	 * apply the weasel dont exit strat, weasel will check if he has hit a boundary, then he will warp back to the boundary 
	 * and flip his heading. He warps back because he might be way out of bounds and not move enough to come back... which
	 * causes a crazy loop.
	 */
	public void apply() {
		
		Location weasel = client.getLocation();
		
		
		if(weasel.getXLocation() > 980){
			flipTheWeasel();
		
		
			
		}
		else if(weasel.getXLocation() < 0){
			flipTheWeasel();
		
			
			}
		else if(weasel.getYLocation() > 900){
			flipTheWeasel();
		
			
		}
		else if(weasel.getYLocation() < 0){
			flipTheWeasel();
	
			
				
			}
		}
	
	
	/**
	 * this flips the weasel heading so he or she may leave the out of bounds area
	 */
	public void flipTheWeasel(){
		
		int weahead = client.getHeading();
		
		if(weahead>180){
			client.setHeading(weahead + 45);
			}
		else if(weahead<180){
			client.setHeading(weahead - 45);	
		}
	}
	
	public String toString(){
		return "Current Strategy: Don't Exit";
	}
	
	
}
	

