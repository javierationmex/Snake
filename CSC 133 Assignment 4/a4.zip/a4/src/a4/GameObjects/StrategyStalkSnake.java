package a4.GameObjects;

import a4.main.GameWorld;
import a4.main.GameWorldProxy;
import a4.main.iObserver;

public class StrategyStalkSnake implements Strategy, iObserver{
	private Weasel client;
	private Location weazel;
	private Location snakeHead;
	private float snakeX =0;
	private float snakeY =0;
	private float weaselX;
	private float weaselY;
	
	/**
	 * this cons is used for observing purposes
	 */
	public StrategyStalkSnake(){
		
	}
	/**
	 * this is the cons used inside the weasel
	 * @param client
	 * takes the weasel in
	 * @param x
	 * takes the weasel location
	 * @param j
	 * takes the weasel heading
	 * and then does apply();
	 */
	public StrategyStalkSnake(Weasel client, Location x, int j, GameWorld g){
		 
		
		this.client = client;
	
		apply();
		
		
	}
	/**
	 * The weasel Stalking logic: This simply finds the angle of the line between the 
	 * weasel and the snake, then it does some angle math, performs the correct subtraction or addition
	 * on the
	 *  weasels heading and then life is good, this was probably the most fun thing I've done
	 * in all of my programming at csus
	 */
	public void apply() {
		
		//snakeX = (int)getSnakeHead().getXLocation();
		//snakeY = (int)getSnakeHead().getYLocation();

		
		weaselX = (int)client.getLocation().getXLocation();
		
		weaselY = (int)client.getLocation().getYLocation();
	//this needs to get the weasel info to work

		float deltaX = snakeX-weaselX;
		float deltaY = snakeY-weaselY;	
		
	
		int stalkerHeading = (int)Math.toDegrees(Math.atan2(deltaX, deltaY));
		
		
		
		//snake GREATER AND GREATER
		if(snakeX>weaselX && snakeY>weaselY){
			client.setHeading(360 - stalkerHeading);
		
		}
		//SNAKE GREATER AND LESS
		else if(snakeX>weaselX && snakeY<weaselY){
			client.setHeading(360 - stalkerHeading);
		
		}
		//SNAKE LESS AND GREATER
		else if(snakeX<weaselX && snakeY>weaselY){
			client.setHeading(stalkerHeading + 360);
			
		}
		//SNAKE LESS AND LESS
		else if(snakeX<weaselX && snakeY<weaselY){
			client.setHeading(stalkerHeading + 360);
		}
		
	}
	
	public String toString(){
		return "Current Strategy: Stalk Snake";
	}
	

	/**
	 * The update since this guy is an observer, he takes snakehead location and the x and y location.
	 */
	
	
	public void update(GameWorldProxy p) {
		snakeHead = p.getSnakeHead();
		weazel = p.getWeaselLoc();	
	}


}
