package a4.GameObjects;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.util.Random;

import a4.main.GameWorld;
import a4.main.ISelectable;

public class TotalBird extends Movable implements ISelectable, IDrawable, ICollider {
	private BirdBody myBird;
	private BirdBeak[] beak;
	private BirdWing[] wing;
	private double wingOffset = 0;
	private double wingIncrement = +.05;
	private double maxWingOffset = .5;
	private boolean isSelected;
	private double wingRotOffset = 0;
	private double wingMotion = +.05;
	private double wingRotation = 1;
	private AffineTransform myTranslation, myRotation, myScale;
	private float m,n;
	private boolean isHit;
	private String hit = "No";
	private GameWorld gw;
	
	public TotalBird(float x, float y, GameWorld GW){
		getLocation().setLocation(x, y);
		myTranslation = new AffineTransform();
		myTranslation.translate(x, y);
		myRotation = new AffineTransform();
		myScale = new AffineTransform();
		myBird = new BirdBody();
		this.setHeading();
		this.rotate(-getHeading());
		//test growth
		//for translate i believe i would do... this.getLocation and then + numbers
		myBird.scale(1.5, 1);
		gw = GW;
		
		
		beak = new BirdBeak[6];
		
		wing = new BirdWing[1];
		
		
		
		//left wings
		BirdBeak f0 = new BirdBeak(); f0.translate(0,-10); f0.rotate(90); f0.scale(3.2,4.5);
		beak[0] = f0; 
		
		BirdBeak f2 = new BirdBeak(); f2.translate(0,-10); f2.rotate(92); f2.scale(3.2,4.5);
		beak[2] = f2; 
		
		BirdBeak f3 = new BirdBeak(); f3.translate(0,-10); f3.rotate(88); f3.scale(3.2,4.5);
		beak[3] = f3; 
		
		
		//right wings
		BirdBeak f1 = new BirdBeak(); f1.translate(0,-10); f1.rotate(-90);f1.scale(3.2,4.5);
		beak[1] = f1; 
		
		BirdBeak f4 = new BirdBeak(); f4.translate(0,-10); f4.rotate(-92);f4.scale(3.2,4.5);
		beak[4] = f4; 
		
		BirdBeak f5 = new BirdBeak(); f5.translate(0,-10); f5.rotate(-88);f5.scale(3.2,4.5);
		beak[5] = f5; 
		
		
		//the beak
		BirdWing j0 = new BirdWing(); j0.translate(0, 7); j0.rotate(180);j0.scale(3.2,4.5);;
		wing[0] = j0;
	

	}
	
	public void rotate (double degrees){
		myRotation.rotate(Math.toRadians(degrees));
	
	}
	
	public void translate(double dx, double dy){
		myTranslation.translate(dx, dy);
	}
	
	public void scale(double sx, double sy){
		myScale.scale(sx, sy);
	}

	@Override
	public void draw(Graphics2D g2d) {
		AffineTransform at = g2d.getTransform();
		if(isSelected()){
			
		
		g2d.transform(myTranslation);
		g2d.transform(myRotation);
		g2d.transform(myScale);
		g2d.setColor(Color.pink);
		
		for (BirdBeak f: beak){
			f.draw(g2d);
			this.update();
			
		}
		for(BirdWing k: wing){
			k.draw(g2d);

			this.update();
		}
		myBird.draw(g2d);
		}
		
		else{
			g2d.transform(myTranslation);
			g2d.transform(myRotation);
			g2d.transform(myScale);
			g2d.setColor(Color.green);
			
			for (BirdBeak f: beak){
				f.draw(g2d);
				this.update();
				
			}
			for(BirdWing k: wing){
				k.draw(g2d);

				this.update();
			}
			myBird.draw(g2d);	
		}
		g2d.setTransform(at);
		}

	@Override
	public void setStrategy(Strategy s) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void invokeStrategy() {
		// TODO Auto-generated method stub
		
	}
	public void setHeading(){
		
		m = (float) ((((Math.random()*20)+1)-10)/10);
		n =  (float) ((((Math.random()*20)+1)-10)/10);
	}
	
	public void update(){
		myTranslation.translate(n, m);

		
		wingRotOffset += wingMotion;
	
		this.getLocation().setLocation((float)myTranslation.getTranslateX(), (float)myTranslation.getTranslateY());
		wingOffset += wingIncrement;
		for( BirdBeak f: beak) {
			
			f.translate(0, wingOffset);
			f.rotate(wingRotOffset);
		}
		
		
		if(Math.abs(wingRotOffset) >= wingRotation){
			wingMotion *= -1;
		}
		
		
		if(Math.abs(wingOffset) >= maxWingOffset){
			wingIncrement *= -1;
		}
		
		
	}

		public boolean collidesWith(ICollider obj) {
			boolean result = false;
			//xlocation + 1/2 width + 1/2 height
			//xlocation + 1/2 width - 1/2 height
			//xlocation - 1/2 width + 1/2 height
			//xlocation - 1/2 width - 1/2 height

			int R1 = (int) (myTranslation.getTranslateX() + 10);
			int L1 = (int) (myTranslation.getTranslateX() - 10);
			int T1 = (int) (myTranslation.getTranslateY() - 10);
			int B1 = (int) (myTranslation.getTranslateY() + 10);
			
			if(obj instanceof Snake){
				Snake s = (Snake) obj;
				Location loc = s.getHeadLoc();

				int T2 = (int) (loc.getYLocation() - (s.getSize()/2) /*+ (getWidth()/2)*/);
				int R2 = (int) (loc.getXLocation() + (s.getSize()/2));
				int B2 = (int) (loc.getYLocation() + (s.getSize()/2) /*+ (getWidth()/2)*/);
				int L2 = (int) (loc.getXLocation() - (s.getSize()/2));
				
				boolean lrOverlap = (R1 > L2) && (L1 < R2);
				boolean tbOverlap = (B1 > T2) && (B2 > T1);
				
				
				if (lrOverlap && tbOverlap) {
					gw.deathByCollision();
				}
				
			}
			
			else 	if(obj instanceof TotalBird){
				TotalBird s = (TotalBird) obj;
				Location loc = s.getLocation();

				int T2 = (int) (loc.getYLocation() - (s.getSize()/2) /*+ (getWidth()/2)*/);
				int R2 = (int) (loc.getXLocation() + (s.getSize()/2));
				int B2 = (int) (loc.getYLocation() + (s.getSize()/2) /*+ (getWidth()/2)*/);
				int L2 = (int) (loc.getXLocation() - (s.getSize()/2));
				
				boolean lrOverlap = (R1 > L2) && (L1 < R2);
				boolean tbOverlap = (B1 > T2) && (B2 > T1);
				
				
				if (lrOverlap && tbOverlap) {
					myRotation.rotate(20);
				}
				
			}
			else 	if(obj instanceof Wall){
				Wall s = (Wall) obj;
				Location loc = s.getLocation();

				int T2 = (int) (loc.getYLocation() - (s.getSize()/2) /*+ (getWidth()/2)*/);
				int R2 = (int) (loc.getXLocation() + (s.getSize()/2));
				int B2 = (int) (loc.getYLocation() + (s.getSize()/2) /*+ (getWidth()/2)*/);
				int L2 = (int) (loc.getXLocation() - (s.getSize()/2));
				
				boolean lrOverlap = (R1 > L2) && (L1 < R2);
				boolean tbOverlap = (B1 > T2) && (B2 > T1);
				
				
				if (lrOverlap && tbOverlap) {
					myRotation.rotate(360);
				}
				
			}
			
			return result;
			
			
		}
	public void isHit(boolean hityesNo){
		if(hityesNo == true){
			System.out.println("HIT");
			hit ="Yes";
		}
		else if(hityesNo == false){
			hit = "No";
		}
		isHit = hityesNo;
	}

	@Override
	public void handleCollision(ICollider obj) {
		if(obj instanceof Snake)
		{
			
			
		System.out.println("BUMP");
			
			}
		}
	
	
	public String toString(){
		return "Bird:" + super.toString() + " size:" + getSize();
	
	}

	@Override
	public void setSelected(boolean yesNo) {
		isSelected = yesNo;
		
	}

	@Override
	public boolean isSelected() {
		return isSelected;
	}

	@Override
	public boolean contains(Point2D p) {
		int px = (int)p.getX();
		int py = (int)p.getY();
		int xLoc = (int)this.getLocation().getXLocation();
		int yLoc = (int)this.getLocation().getYLocation();
		if( (px >= xLoc) && (px <= xLoc + this.getSize())
				&& (py >= yLoc) && (py <= yLoc+getSize()))
		return true;
		else return false;
	}

	}


