
package a4.GameObjects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;

import a4.main.GameWorld;

/*
 * This program was designed by Daniel Baptista for CSC133
 * It has been finished on 10/15/2014
 */




public class Wall extends Fixed implements IDrawable, ICollider{
	
	private int width = 0;
	private int height = 0;
	private GameWorld gw;
	private AffineTransform myTranslation, myRotation, myScale;
	
public Wall(){
}
/**
* Wall constructor: takes parameter of int( x, y, w, h)
*/
public Wall(float x, float y, int w, int h, GameWorld GW){
	getLocation().setLocation(x, y);
	myTranslation = new AffineTransform();
	myTranslation.translate(x, y);
	myRotation = new AffineTransform();
	myScale = new AffineTransform();
	width = w;
	height = h;
	gw = GW;

}

public Rectangle getBounds(){
	return new Rectangle((int)this.rGetLocationX(),(int)this.rGetLocationY(),this.getWidth(),this.getHeight());
}

public float rGetLocationX(){
return (float)myTranslation.getTranslateX();
}
public float rGetLocationY(){
	return (float)myTranslation.getTranslateY();
}
public void rotate (double degrees){
	myRotation.rotate(Math.toRadians(degrees));

}

public void translate(double dx, double dy){
	myTranslation.translate(dx, dy);
}

public void scale(double sx, double sy){
	myScale.scale(sx, sy);
}
/**
* Getwidth simply returns width
*/
public int getWidth(){
	return width;
}

/**
* getHeight returns height 
*/
public int getHeight(){
	return height;
}

/**
* String toString
*/
public String toString(){
	return "Wall:" + myTranslation.getTranslateX() + " , " + this.getTranslate().getTranslateY() + " ALSO " + this.getLocation().getXLocation() + " , " + this.getLocation().getYLocation() + " width:" + getWidth() + " height:" + getHeight();
	
}
@Override
public void draw(Graphics2D g2d) {
	AffineTransform at = g2d.getTransform();
	
	g2d.transform(myTranslation);
	g2d.transform(myRotation);
	g2d.transform(myScale);
	g2d.setColor(Color.BLUE);
	g2d.fillRect(0,
			0, this.getWidth(), this.getHeight()); 
			//this.getWidth(), 
			//this.getHeight());
	g2d.setTransform(at);
	this.update();
	}
public void update(){
	
}
@Override
public boolean collidesWith(ICollider obj) {
	boolean result = false;
	//xlocation + 1/2 width + 1/2 height
	//xlocation + 1/2 width - 1/2 height
	//xlocation - 1/2 width + 1/2 height
	//xlocation - 1/2 width - 1/2 height

	int R1 = (int) (myTranslation.getTranslateX() + (getWidth()));
	int L1 = (int) (myTranslation.getTranslateX());
	int T1 = (int) (myTranslation.getTranslateY());
	int B1 = (int) (myTranslation.getTranslateY() + (getHeight()));
	
	if(obj instanceof Snake){
		Snake s = (Snake) obj;
		Location loc = s.getHeadLoc();
		
//		System.out.println("obj trans x = " + ((Snake)obj).getTranslateX());
		int T2 = (int) (loc.getYLocation() - (s.getSize()/2) /*+ (getWidth()/2)*/);
		int R2 = (int) (loc.getXLocation() + (s.getSize()/2));
		int B2 = (int) (loc.getYLocation() + (s.getSize()/2) /*+ (getWidth()/2)*/);
		int L2 = (int) (loc.getXLocation() - (s.getSize()/2));
		
		boolean lrOverlap = (R1 > L2) && (L1 < R2);
		boolean tbOverlap = (B1 > T2) && (B2 > T1);
		
		
		if (lrOverlap && tbOverlap) {
			gw.deathByCollision();
		}
		
	

		
	}
	return result;
	
	
}
@Override
public void handleCollision(ICollider obj) {
	if(obj instanceof Snake)
	{
		System.out.println("HI");
		
		}
	}
	
}



	
	


	



	

	
	
	

