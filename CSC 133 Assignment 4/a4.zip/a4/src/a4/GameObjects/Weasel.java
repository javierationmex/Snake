package a4.GameObjects;



import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;

import a4.GameObjects.Strategy;
import a4.GameObjects.StrategyDontExit;
import a4.GameObjects.StrategyStalkSnake;
import a4.main.GameWorld;
import a4.main.GameWorldProxy;
import a4.main.ISelectable;
import a4.main.iObserver;
public class Weasel extends Movable implements iSteerable, IDrawable, ICollider, ISelectable{
	
		
	private StrategyDontExit SDE;
	private StrategyStalkSnake SSS;
	private GameWorld gw;
	private Snake sn;
	private boolean isSelected;
	private AffineTransform myTranslation, myRotation, myScale;
	private float m,n;
	private Location snakeHead;
	private float snakeX;
	private float snakeY;
	private int life;
	private boolean flag;
	/**
	 * this is the Weasel cons, when its constructed it will have the 2 strategies defined.
	 */
	public Weasel(GameWorld g, float x, float y){
		
		gw = g;
		setSize(35);
		life = 2500;
		this.getLocation().setLocation(x, y);
		setHeading();
		SDE = new StrategyDontExit(this, this.getLocation(), this.getHeading());
		setStrategy(SDE);
		SSS = new StrategyStalkSnake(this, this.getLocation(), this.getHeading(), g);
		myTranslation = new AffineTransform();
		myTranslation.translate(x, y);
		myRotation = new AffineTransform();
		myScale = new AffineTransform();
		this.apply();
		
	}
	
	public void rotate (double degrees){
		myRotation.rotate(Math.toRadians(degrees));
	
	}
	
	public void translate(double dx, double dy){
		myTranslation.translate(dx, dy);
	}
	
	public void scale(double sx, double sy){
		myScale.scale(sx, sy);
	}
	/**
	 * Move for the weasel, will do an if statement that it receives from steerable and then apply the 
	 * right strategy
	 */
	public void apply(){
		snakeHead = gw.getSnakeHead();
		
		snakeX = snakeHead.getXLocation();
		snakeY = snakeHead.getYLocation();
		Location weasel = this.getLocation();
		float weaselX = weasel.getXLocation();
		float weaselY = weasel.getYLocation();
		

		float deltaX = snakeX-weaselX;
		float deltaY = snakeY-weaselY;	
		
		
		int stalkerHeading = (int)Math.toDegrees(Math.atan2(deltaX, deltaY));
		
	

		//snake GREATER AND GREATER
		if(snakeX>weaselX && snakeY>weaselY){
			this.setHeading(360 - stalkerHeading);
		
		}
		//SNAKE GREATER AND LESS
		else if(snakeX>weaselX && snakeY<weaselY){
			this.setHeading(360 - stalkerHeading);
		
		}
		//SNAKE LESS AND GREATER
		else if(snakeX<weaselX && snakeY>weaselY){
			this.setHeading(stalkerHeading + 360);
			
		}
		//SNAKE LESS AND LESS
		else if(snakeX<weaselX && snakeY<weaselY){
			this.setHeading(stalkerHeading + 360);
		}
		
	}
	public void move(){
		super.move();
		
	
		
		//if(curStrategy == SDE){
		//	SDE.apply();
		//}
		//else if(curStrategy == SSS){
		//	SSS.apply();
	//	}
		
		

	}
	public String toString(){
		return "Weasel:" + super.toString();
		
	}

	
	public void steerable(int param) {
		
		
			
			if(param == 1){
				setStrategy(SDE);	
			}else if(param == 2){
				setStrategy(SSS);	
			}					
}

	/**
	 * sets the strategy of the weasel
	 */
	public void setStrategy(Strategy s) {
		curStrategy = s;
	}
	/**
	 * getter of strategy
	 * @return
	 */
	public Strategy getStrategy(){
		return curStrategy;
	}

	@Override
	public void invokeStrategy() {
		// TODO Auto-generated method stub
		
	}

	 public int getLifeTime()
	 {
		 return life;
	 }
	 
	 public void setLifeTime(int lifeTime)
	 {
		 this.life = lifeTime;
	 }
	 
	 
	 
	 public void setFlag(boolean b)
	 {
		 flag = b;
	 }
	 
	 public boolean getFlag()
	 {
		 return flag;
	 }
	@Override
	public void draw(Graphics2D g2d) {
		AffineTransform at = g2d.getTransform();
		
		if(isSelected()){
			
			g2d.transform(myScale);
			g2d.transform(myTranslation);
			g2d.transform(myRotation);
		
			g2d.setColor(Color.pink);
			g2d.fillRect(0, 0, this.getSize(), this.getSize());
			g2d.setTransform(at);
			this.update();
		}
		else{

			g2d.transform(myScale);
			g2d.transform(myTranslation);
			g2d.transform(myRotation);
		
			g2d.setColor(Color.magenta);
		
			g2d.drawRect(0, 0, this.getSize(), this.getSize());
			g2d.setTransform(at);
			this.update();
		}
	
	}


	@Override
	public boolean collidesWith(ICollider otherObject) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public void handleCollision(ICollider otherObject) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void setSelected(boolean yesNo) {
		isSelected = yesNo;
		
	}

	@Override
	public boolean isSelected() {
		return isSelected;
	}

	@Override
	public boolean contains(Point2D p) {
		int px = (int)p.getX();
		int py = (int)p.getY();
		int xLoc = (int)this.getLocation().getXLocation();
		int yLoc = (int)this.getLocation().getYLocation();
		if( (px >= xLoc) && (px <= xLoc + getSize())
				&& (py >= yLoc) && (py <= yLoc+getSize()))
		return true;
		else return false;
	}

public void setHeading(){
		
		m = (float) ((((Math.random()*20)+1)-10)/10);
		n =  (float) ((((Math.random()*20)+1)-10)/10);
	}
	
	public void update(){
		myTranslation.translate(n*getSpeed(), m*getSpeed());
		myRotation.rotate(.01);
		this.getLocation().setLocation((float)myTranslation.getTranslateX(), (float)myTranslation.getTranslateY());
	}

	

		
	}
		

	
	

