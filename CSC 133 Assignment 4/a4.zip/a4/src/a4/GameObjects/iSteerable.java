package a4.GameObjects;
/*
 * This program was designed by Daniel Baptista for CSC133
 * It has been finished on 10/15/2014
 */


/**
* Interface iSteerable: I believe this is just like a .h from C++ so all I do here is declare the steerable 
* method
*/
public interface iSteerable {
	

	public void steerable(int param);
}
