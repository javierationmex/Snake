package a4;

import a4.main.Game;

/**
* Everything begins from this
*/
public class Starter {

	public static void main(String[]args){
		
		Game g = new Game();
		
		}
}
