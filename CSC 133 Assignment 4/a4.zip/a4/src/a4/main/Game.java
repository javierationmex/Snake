package a4.main;



import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.Timer;

import a4.GameObjects.Bezier;
import a4.GameObjects.GameObject;
import a4.GameObjects.ICollider;
import a4.GameObjects.IDrawable;
import a4.GameObjects.Movable;
import a4.GameObjects.StrategyStalkSnake;
import a4.GameObjects.Weasel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

/*
 * This program was designed by Daniel Baptista for CSC133
 * It has been finished on 10/15/2014
 */
/**
 * Tis is 
 * @author Lord
 *
 */



@SuppressWarnings("serial")
public class Game extends JFrame implements ActionListener {
	
	private GameWorld gw;
	private MapView mv;
	private ScoreView sv;
	private StrategyStalkSnake sss;
	private JButton 	delete,  gameQuit, pause;
	private int i = 0;
	
	/**
	 * Timer
	 */
	private Timer timer;
	
	/**
	 * This makes my FPS a buttery smooth 60 FPS
	 */
	private final int DELAY_IN_MSEC=1000/60;
	
	
	
	/**
	* This is a JavaDoc comment, it's blue
	* Game is going to do a new gameworld and then initialize everything. It will then go to
	* play.
	*/
	public Game(){
		//this used to be just gw = new GameWorld();
		gw = new GameWorld();
		gw.initLayout();
		//registers mapview as the gameworld observer
		mv = new MapView();
		sv = new ScoreView();
		sss = new StrategyStalkSnake();
		gw.addObserver(mv);
		gw.addObserver(sv);
		gw.addObserver(sss);
		
		
		/**
		 * Timer part START
		 */
		
		timer = new Timer(DELAY_IN_MSEC, this);
		
		//testing time
	
		
		timer.setRepeats(true);
		timer.start();
		
		//END timer stuff
		//This is the Frame Code there is going to be a lot of it 
		
		
		setSize(1200, 1000);
		setLocation(500,1);
	
		setTitle("Snake");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
			
		
				
		//frame Code ends here ********************
		//This is the menu bar Code
				JMenuBar bar = new JMenuBar();		
				setJMenuBar(bar);
				JMenu fileMenu = new JMenu("File");
				bar.add(fileMenu);
				JMenu commandMenu = new JMenu("Commands");
				bar.add(commandMenu);
				
				
				//create abstractions(commands) to attach to file menu items
				New newCommand = new New();
				Save saveCommand = new Save();
				Undo undoCommand = new Undo();
				Sound soundCommand = new Sound();
				About aboutCommand = new About();
				Quit quitCommand = new Quit();
				Delete deleteCommand = new Delete();
				
				//create abstractions(commands to attach to commands menu items and commands buttons
				SnakeHitsBody bodyCommand = new SnakeHitsBody();
				
				ChangeStrategies strategyCommand = new ChangeStrategies();
			
				Pause	pauseCommand = new Pause();
				
				//create abstractions(commands) to attach to keybindings
				North northCommand = new North();
				East eastCommand = new East();
				South southCommand = new South();
				West westCommand = new West();
				
				//create menu items File -> New/Save/Undo/Sound/About
				JMenuItem fileNew = new JMenuItem("New");
				JMenuItem fileSave = new JMenuItem("Save");
				JMenuItem fileUndo = new JMenuItem("Undo");
				JCheckBoxMenuItem fileSound = new JCheckBoxMenuItem("Sound", false);
				JMenuItem fileAbout = new JMenuItem("About");
				JMenuItem fileQuit = new JMenuItem("Quit");
				
				//create menu items Commands -> Snake hits Body/Snake hits Bird/Snake hits Money
				//Snake eats food/ Snake hits Wall/ Weasel hits Snake / Change Strategies
				JMenuItem commandsBody = new JMenuItem("Snake hits Body");
				JMenuItem commandsBird = new JMenuItem("Snake hits Bird");
				JMenuItem commandsMoney = new JMenuItem("Snake hits Money");
				JMenuItem commandsFood = new JMenuItem("Snake eats Food");
				JMenuItem commandsWall = new JMenuItem("Snake hits Wall");
				JMenuItem commandsWeasel = new JMenuItem("Weasel hits Snake");
				JMenuItem commandsStrategies = new JMenuItem("Change Strategies");
				
				
				
				//add menu items to File Menu
				fileMenu.add(fileNew);
				fileMenu.add(fileSave);
				fileMenu.add(fileUndo);
				fileMenu.add(fileSound);
				fileMenu.add(fileAbout);
				fileMenu.add(fileQuit);
				
				//add menu items to Command Menu
				commandMenu.add(commandsBody);
				commandMenu.add(commandsBird);
				commandMenu.add(commandsMoney);
				commandMenu.add(commandsFood);
				commandMenu.add(commandsWall);
				commandMenu.add(commandsWeasel);
				commandMenu.add(commandsStrategies);
				
				//add commands to file menu items
				fileNew.setAction(newCommand);
				fileSave.setAction(saveCommand);
				fileUndo.setAction(undoCommand);
				fileSound.setAction(soundCommand);
				fileAbout.setAction(aboutCommand);
				fileQuit.setAction(quitCommand);
				
				//add commands to commands menu items
				commandsBody.setAction(bodyCommand);
				
				commandsStrategies.setAction(strategyCommand);
				
				
				//This is the top panel Code
			
			//	topPanel.setBorder(new LineBorder(Color.blue, 2));
				//add(topPanel, BorderLayout.NORTH);
				
				add(sv.getPanel(), BorderLayout.NORTH);
				
				
				
				//This is the code left panel and all the buttons included with it
				JPanel leftPanel = new JPanel();
				leftPanel.setBorder(new TitledBorder("Commands: "));
				leftPanel.setLayout(new GridLayout (10,1));
				add(leftPanel, BorderLayout.WEST);
				
				
				
				//Buttons being added to the left panel
				
				delete = new JButton("Delete");
				
				pause = new JButton("Pause");
				gameQuit = new JButton("Quit");
				
				delete.getInputMap().put(KeyStroke.getKeyStroke("SPACE"), "none");
				
				gameQuit.getInputMap().put(KeyStroke.getKeyStroke("SPACE"), "none");
				pause.getInputMap().put(KeyStroke.getKeyStroke("SPACE"), "none");
				
				//adds the buttons to the left panel
			
				
				leftPanel.add(pause);
				leftPanel.add(delete);
				leftPanel.add(gameQuit);
				
				
				//adds commands to the buttons
				
				pause.setAction(pauseCommand);
				delete.setAction(deleteCommand);
				gameQuit.setAction(quitCommand);
				
				delete.setEnabled(false);
				//this is the center panel
				//	JPanel centerPanel = new JPanel();
				//	/add(centerPanel,BorderLayout.CENTER);
				//add(mv.getPanel(), BorderLayout.CENTER);
			
				add(mv, BorderLayout.CENTER);
				//create a timer and start it firing actionevents
		
				
		
				
				
				
				//buttons used for keystrokes
				JButton north = new JButton("North");
				north.setAction(northCommand);
				JButton east = new JButton("East");
				east.setAction(eastCommand);
				JButton south = new JButton("South");
				south.setAction(southCommand);
				JButton west = new JButton("West");
				west.setAction(westCommand);
				
				JButton reset = new JButton("New");
				reset.setAction(newCommand);
				
				//get the focus is in the window input map for the center panel
				int mapName = JComponent.WHEN_IN_FOCUSED_WINDOW;
				//InputMap imap = mv.getPanel().getInputMap(mapName);
				InputMap imap = mv.getInputMap(mapName);
				//disable going back onto yourself
				north.getInputMap().put(KeyStroke.getKeyStroke("DOWN"), "none");
				//create a keystroke object to represent "n, e, s, w" keys VK_LEFT
				
				KeyStroke upKey = KeyStroke.getKeyStroke("UP");
				imap.put(upKey, "North");
				
				KeyStroke rightKey = KeyStroke.getKeyStroke("RIGHT");
				imap.put(rightKey, "East");
				
				KeyStroke downKey = KeyStroke.getKeyStroke("DOWN");
				imap.put(downKey, "South");
				
				KeyStroke leftKey = KeyStroke.getKeyStroke("LEFT");
				imap.put(leftKey,  "West");
				/*
				 * WASD because I gamed in the 80s/90s with arrow keys and I think it sucked.
				 */
				KeyStroke wKey = KeyStroke.getKeyStroke('w');
				imap.put(wKey, "North");
				
				KeyStroke sKey = KeyStroke.getKeyStroke('s');
				imap.put(sKey, "South");
				
				KeyStroke aKey = KeyStroke.getKeyStroke('a');
				imap.put(aKey, "West");
				
				KeyStroke dKey = KeyStroke.getKeyStroke('d');
				imap.put(dKey, "East");
				// TEST
				KeyStroke rKey = KeyStroke.getKeyStroke('r');
				imap.put(rKey, "New");
				
				
				
				//get the action map for the panel
				//ActionMap amap = mv.getPanel().getActionMap();
				ActionMap amap = mv.getActionMap();
				//put the n e s w objects into the panels actionmap
				amap.put("North", northCommand);
				amap.put("East", eastCommand);
				amap.put("South", southCommand);
				amap.put("West", westCommand);
				
				amap.put("New", newCommand);
				
				//TESTING THE SPACE COMMAND
				imap.put(KeyStroke.getKeyStroke(KeyEvent.VK_SPACE, 0), "space");
				amap.put("space", strategyCommand);
				
				setVisible(true);			
	}
	
	
/*
 * These are the Commands / File Commands actions
 */
	
	public class SnakeHitsBody extends AbstractAction{

		public SnakeHitsBody(){
			super("Snake hits Body(1)");
			}
			@Override
			public void actionPerformed(ActionEvent e) {
				
				System.out.println("You hit your body.");

				gw.deathByCollision();
				
			}
	}
	
	
	
	
	
	
	
	


	public class ChangeStrategies extends AbstractAction{

			
		public ChangeStrategies(){
				super("Change Strategies");
			}
			@Override
			public void actionPerformed(ActionEvent e) {
		
				if(i == 0){
				i = 1;
					gw.spacePress(1);
					System.out.println("Strategy changed to: Strategy Don't Exit");
				}
				else if(i == 1){
					i = 0;
					gw.spacePress(2);
					System.out.println("Strategy changed to: Strategy Stalk Snake");
					
				}
				
			}
	}

	
/*
-------------------------------------------------------
These are the file menu classes
-------------------------------------------------------
*/
public class New extends AbstractAction{
	public New(){
		super("New");
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		
		
		
		gw.reset();
		timer.start();
	
		gw.initLayout();
		
	}
}


public class Save extends AbstractAction{
	public Save(){
		super("Save");
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}

public class Undo extends AbstractAction{
	public Undo(){
		super("Undo");
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
/**
* SOUND CHECK BOX
 *
 */
public class Sound extends AbstractAction{
	private JCheckBoxMenuItem onOff;
	public Sound(){
		super("Sound");
	
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		onOff = (JCheckBoxMenuItem)e.getSource();
		if(onOff.isSelected())
		{
			gw.soundONOFF(true);
		}
		else{
			gw.soundONOFF(false);
		}
	}
	
	
}

public class About extends AbstractAction{
	public About(){
		super("About");
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
System.out.println("About requested from " + e.getActionCommand() + " " + e.getSource().getClass());
		timer.stop();
		 JOptionPane.showConfirmDialog(null, 
				"This program was created by Daniel Baptista for CSC133.", 
				"Version 3.0", 
				JOptionPane.PLAIN_MESSAGE,
				JOptionPane.QUESTION_MESSAGE);
		 timer.start();
		return;
		
	}
}

public class Pause extends AbstractAction{
	public Pause(){
		super("Pause");
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(gw.getPause() == false){
			
			timer.stop();
			pause.setText("Play");
			delete.setEnabled(true);
			
			gw.setPause(true);
			}
			else if(gw.getPause() == true){
				
				timer.start();
				gw.removeSelection();
				pause.setText("Pause");
				delete.setEnabled(false);
				gw.setPause(false);
				
			}
			
		}
	}
public class Delete extends AbstractAction{
	public Delete(){
		super("Delete");
	}

	@Override
	public void actionPerformed(ActionEvent e) {
	
		gw.deleteSelected();
		gw.tick();
	}
}	

public class Quit extends AbstractAction{
	public Quit(){
		super("Quit");
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("Quit requested from " + e.getActionCommand() + " " + e.getSource().getClass());
		
		int result = JOptionPane.showConfirmDialog(null, 
				"You sure you want to exit?", 
				"Confirm Exit", 
				JOptionPane.YES_NO_OPTION,
				JOptionPane.QUESTION_MESSAGE);
		
		if (result == JOptionPane.YES_OPTION){
			System.exit(0);
		}
		return;
		
	}
}
/*
 * 
 * These are the key bindings! N E S W assigned to arrows up right down left
 *
 */



public class North extends AbstractAction{
	public North(){
		super("North");
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		gw.north();
		
		
	}
}

public class East extends AbstractAction{
	public East(){
		super("East");
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		gw.east();
		
	}
}

public class South extends AbstractAction{
	public South(){
		super("South");
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		gw.south();
		
	}
}

public class West extends AbstractAction{
	public West(){
		super("West");
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		gw.west();
		
	}
}
//Timer delay, each time you die this will be invoked and you will wait 3 seconds before starting up again.
public void timerDelay(){
	timer.restart();
}


@Override
public void actionPerformed(ActionEvent e) {

	
	for(GameObject got : gw.OBCollection){
		if(got instanceof Movable){
			((Movable) got).move();
		}
	gw.tick();
	
	
	for(GameObject bez : gw.OBCollection){
		if(bez instanceof Bezier){
			if((((Bezier) bez).getLifeTime() > 0)){
				int BezierLifeTime = ((Bezier) bez).getLifeTime();
				BezierLifeTime--;
				((Bezier) bez).setLifeTime(BezierLifeTime);}
			else{
				gw.bezierDeath();
			}
			}
	}
	

	
	for(GameObject curObj : gw.OBCollection){
		if(curObj instanceof ICollider){	
	for(GameObject otherObject : gw.OBCollection){
				if(otherObject instanceof ICollider){
					
					if(otherObject != curObj){
						if(((ICollider) curObj).collidesWith((ICollider) otherObject)){
							((ICollider) curObj).handleCollision((ICollider)otherObject);
							
						}
						}
							
						}
					}
				}
			}
	
	}
	}
	


}








	
	