package a4.main;

import java.util.ArrayList;
import java.util.Iterator;

import a4.GameObjects.GameObject;
/**
 * the Game Collection class: I've titled it irritable because doing this caused me a lot of frustration
 * this class will let you run an iterator through the collection of objects.
 * 
 *
 */

public class GameCollectionIrritable implements Iterable<GameObject>{

	private ArrayList<GameObject> theCollection;
	
	public GameCollectionIrritable(){
		theCollection = new ArrayList<GameObject>();
		
	}

	public int size(){
		return theCollection.size();
	}
	
	public void add(GameObject newObject) {
		this.theCollection.add( newObject);
		
	}
	
	
	public void remove(GameObject o){
		theCollection.remove(o);
	}

	public void empty(){
		theCollection.removeAll(theCollection);
	}
	
	public Iterator<GameObject> getIterator() {
		return new gameObjectIterator();
	}

	
private class gameObjectIterator implements Iterator<GameObject>{
		
		private int currElementIndex;
		
		
		
		public gameObjectIterator(){
			currElementIndex = -1;
		}
		
		public boolean hasNext(){
			if(theCollection.size() <= 0) return false;
			if(currElementIndex == theCollection.size() -1)
				return false;
			return true;
		}
		
		
		
		public void remove(){
			theCollection.remove(currElementIndex);
		}
		@Override
		public GameObject next() {
			currElementIndex++;
			return (theCollection.get(currElementIndex));
		}
	
		
	
	}


public Iterator<GameObject> iterator() {
	
	return new gameObjectIterator();
}




}
