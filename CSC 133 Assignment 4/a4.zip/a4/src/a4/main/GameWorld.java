package a4.main;












import java.awt.Graphics;
import java.io.File;
import java.util.ArrayList;

import a4.GameObjects.*;

 
 
 
/*
 * This is my Controller
 * 
 */
public class GameWorld extends Observerable implements iObservable, iGameWorld{
	
	private int time=0;
	private int secTime;
	private int lives=3;
	private int score=0;
	private int snakeCount = 1;
	private String sound = "Off";	
	
	
	private boolean soundONOFF = false;	
	private boolean pauseONOFF = false;
	private boolean isSelected;
	 GameCollectionIrritable OBCollection;
	 //sound declared
	 private Sound BGM;
	 private Sound eatFood;
	 private Sound gameOver;
	 private Sound moneyGot;
	 private Sound animalCollision;
	 
//test
	//sound directory THIS MAKES IT WORK IN THE COMPILER
	public static final String soundDir = "." + File.separator + "a4" + File.separator + "sounds" + File.separator;	
			 
	//public static final String soundDir = "." + File.separator + "src" + File.separator + "a4" + File.separator
	//		+ "sounds" + File.separator;
	 
	 public static final String BGMSF = "snakeBGM.wav";
	 public static final String eatFoodSF = "foodCollision.wav";
	 public static final String gameOverSF = "gameOver.wav";
	 public static final String moneyGotSF = "moneyCollision.wav";
	 public static final String animalCollisionSF = "animalCollision.wav";
	 
	 
	 public static final String BGMSFP = soundDir + BGMSF;
	 public static final String eatFoodSFP = soundDir + eatFoodSF;
	 public static final String gameOverSFP = soundDir + gameOverSF;
	 public static final String moneyGotSFP = soundDir + moneyGotSF;
	 public static final String animalCollisionSFP = soundDir + animalCollisionSF;
	/**
	* Code here to create the initial game objects/layout
	*/
	public Snake makeSnake(float x, float y){ return new Snake(this, x, y);}
	public Bird makeBird(){ return new Bird();}
	public TotalBird makeTotalBird(float x, float y){return new TotalBird(y, x, this);}
	public Food makeFood(float x, float y){ return new Food(x, y);}
	public Money makeMoney(float x, float y){ return new Money(x, y);}
	public Weasel makeWeasel(float x, float y){ return new Weasel(this, x, y);}
	public Wall makeWall(int w, int x, int y, int z){ return new Wall(w, x, y, z, this);}
	public Bezier makeBezier(float x, float y){return new Bezier(this, x,y);}
	public void reset(){
		time = 0;
		lives = 3;
		score = 0;
		
	}
	public void initLayout(){
	
		
	
	eatFood = new Sound(eatFoodSFP); //this is the food col sound
	moneyGot = new Sound(moneyGotSFP);
	animalCollision = new Sound(animalCollisionSFP);
	gameOver = new Sound(gameOverSFP);
	BGM = new Sound(BGMSFP);
	//creates the collection
	OBCollection = new GameCollectionIrritable();
	
	//add some objects to the collection - totally using the doctors book here.
	
	OBCollection.add(new Snake(this, (float)0, (float)0));
	
	//OBCollection.add(new Bird());
	
	OBCollection.add(new Food((float)Math.random()*900, (float)Math.random()*900));
	OBCollection.add(new Money((float)Math.random()*900, (float)Math.random()*900));
	//walls x y height and width
	//vert
	
	
	
	OBCollection.add(new Wall((float)(Math.random()*500), (float)(Math.random()*800%800+800), 12, 500, this));
	//hori
	OBCollection.add(new Wall((float)(Math.random()*500), (float)(Math.random()*1500%1500+1500), 500, 12, this));			//the bottom
	//vert
	OBCollection.add(new Wall((float)(Math.random()*1500), (float)(Math.random()*1500), 12, 500, this));		//not sure   changing 500 to x
	//hori
	OBCollection.add(new Wall((float)(Math.random()*1500), (float)(Math.random()*100), 500, 12, this));
	//vert
		OBCollection.add(new Wall((float)(Math.random()*500), (float)(Math.random()*800), 12, 500, this));
		//hori
		OBCollection.add(new Wall((float)(Math.random()*500), (float)(Math.random()*1500), 500, 12, this));			//the bottom
		//vert
		OBCollection.add(new Wall((float)(Math.random()*1500), (float)(Math.random()*1500), 12, 500, this));		//not sure   changing 500 to x
		//hori
		OBCollection.add(new Wall((float)(Math.random()*1500), (float)(Math.random()*100), 500, 12, this));
	OBCollection.add(new Weasel(this,(float)Math.random()*900, (float)Math.random()*900));

	OBCollection.add(new Weasel(this, (float)Math.random()*900, (float)Math.random()*900));
	
	OBCollection.add(new TotalBird((float)Math.random()*900,(float)Math.random()*900, this));
	OBCollection.add(new Bezier(this, 500, 500));
	}
	
	/**
	* this code is straight from the assignment handout, checks if what it sees in theworldvector if it is movable
	* if it is movable, move it
	*/

public void move(){
	for(GameObject spo : OBCollection){
		 if(spo instanceof Movable){
			 ((Movable) spo).move();
			
		 }	 
	}
	
}
/**
 * Here is some pause stuff	
 * @return
 */
public boolean getPause(){
	return pauseONOFF;
}

public void setPause(boolean t){
	pauseONOFF = t;
}

/*
 * The following removes selection from objects
 */
public boolean removeSelection(){
	for(GameObject spo : OBCollection){
		if(spo instanceof ISelectable){
			((ISelectable) spo).setSelected(false);
		}
	}
	return isSelected = false;
}

/*
 * the following deletes selected objects
 */

public void deleteSelected(){
	for(GameObject spo : OBCollection){
		if(spo instanceof ISelectable){
			if(((ISelectable)spo).isSelected()){
				OBCollection.remove(spo);
			}
		}
	}
}

public void moneyDeath(){
	
	for(GameObject spo : OBCollection){
		if(spo instanceof Money){
			OBCollection.add(new Money( (float)Math.random()*900, (float)Math.random()*900));
				OBCollection.remove(spo);
			
		}
	}
}

public void birdBirth(){
	for(GameObject spo : OBCollection){
		if(spo instanceof TotalBird){
			OBCollection.add(new TotalBird(800, 800, this));
			OBCollection.remove(spo);
		}
	}
}
public void bezierDeath(){
	for(GameObject spo : OBCollection){
		if(spo instanceof Bezier){
			OBCollection.remove(spo);
			OBCollection.add(new Bezier(this, 50, 50));
		}
	}
}
public void addWeasel(){
	OBCollection.add(new Weasel(this, 250,250));
}
public void weaselDeath(){
	for(GameObject spo : OBCollection){
		if(spo instanceof Weasel){
			OBCollection.add(new Weasel(this, 250, 250));
		
				OBCollection.remove(spo);
	
		}
	}
}
/**
* get Time
*/
public int getTime(){
	secTime = (int)(time/1000)%60;
	
	return secTime;
}


/**
* get Lives
*/
public int getLives(){
	return lives;
}

/**
* get Score
*/
public int getScore(){
	
	return score;
}



/**
 * get Sound
 */

public String getSound(){
	return sound;
}

/**
 * get Sound Boolean
 */

public boolean getBSound(){
	return soundONOFF;
}
/**
* addPoints 
*/
private void addPoints(int i){
	score += i;

	this.notifyObservers(getProxy());
	
}

/**
* Death 
*/
private void death(){
	lives = lives -1;
	
	this.notifyObservers(getProxy());
	
}

public Sound eatFood(){
	return eatFood;
}

public Sound gameOver(){
	return gameOver;
}

public Sound moneyGot(){
	return moneyGot;
}

public Sound animalCollision(){
	return animalCollision;
}
/**
* the next 4 methods relate to what comes in from game.java and will set the heading depending on which 
* parameter is passed to s.steerable
*/
public void north(){
	
	
	
	int i = 0;	
	
	
	for(GameObject spo : OBCollection){
		 if(spo instanceof Snake){
			((Snake) spo).steerable(i); 
		 }
		}
	

	}
	
	public void east(){
		
	int i = 90;
	
	for(GameObject spo : OBCollection){
		 if(spo instanceof Snake){
			((Snake) spo).steerable(i); 
		 }
		}
	
	}
	
	public void south(){
		
	int i = 180;
	
	for(GameObject spo : OBCollection){
		 if(spo instanceof Snake){
			((Snake) spo).steerable(i); 
		 }
		}

	}
	
	public void west(){
		
	int i = 270;
	
	for(GameObject spo : OBCollection){
		 if(spo instanceof Snake){
			((Snake) spo).steerable(i); 
		 }
		}

	}
	
	public void spacePress(int n){
		switch(n){
		case 1 : if(n == 1){
			for(GameObject spo: OBCollection){
				if(spo instanceof Weasel){
					((Weasel) spo).steerable(n);}
		}
			
		}
		case 2: if(n == 2){
			for(GameObject spo: OBCollection){
				if(spo instanceof Weasel){
					((Weasel) spo).steerable(n);}
			}
		}
		}
	}
	
		
	
/**
 * Sound ON OFF code, determines what the status of the sound through a passed parameter
 * @param n
 */
	public void soundONOFF(boolean onOff){
		if(onOff == true)
		{
			BGM.loop();
			sound = "On";
			this.notifyObservers(getProxy());
		}
		else if (onOff == false)
		{
			BGM.stop();
			sound = "Off";
			this.notifyObservers(getProxy());
		}
		soundONOFF = onOff;
		
	}

	
	/**
	* causes death, if you have too few lives the game ends, otherwise it will just clear
	* theWorldVector and then initLayout 
	*/	
	public void deathByCollision(){
		death();
		
		if(lives <=0){
			deathSoundCheck();
		
			OBCollection.empty();
			this.notifyObservers(getProxy());

			
		}else{
			
			OBCollection.empty();
			time = 0;
			initLayout();
			
		}
	}
	
	/**
	 * death sound check
	 */
	public void deathSoundCheck(){
		if(soundONOFF == true){
			
			gameOver().play();}
	}
	/**
	* Money Collision, this will increase the money! and add money! and increase your score! fantastic!
	*/
	public void moneyCollision(){
		
	
		
		for(GameObject spo : OBCollection){
			 if(spo instanceof Money){
				OBCollection.remove(spo);
				 addPoints(((Money) spo).getValue());
				OBCollection.add(new TotalBird((float)Math.random()*900,(float)Math.random()*900, this));
				
				
				//OBCollection.remove(spo);
				//OBCollection.add(new Money());
				break;
				}
			}
	
	}
	

	
	
	/**
	* gets the value of food, applies the value of food and throws that into the the snake so it can see how
	* many segments needs to get added.
	*/
	public void foodCollision(){
		int value = 0;
		
		
		for(GameObject spo : OBCollection){
			if(spo instanceof Food){
				value = ((Food) spo).getValue();
					OBCollection.remove(spo);
					OBCollection.add(new Food((float)Math.random()*900, (float)Math.random()*900));
					
				}	
			
			
				
			}
		for(GameObject spo : OBCollection){
			if(spo instanceof Snake){
				((Snake)spo).setNewSegCount(value);
			}
		}
			
		

		OBCollection.add(new Money((float)Math.random()*900, (float)Math.random()*900));
		

	
	}
	



/**
* TICK: This is the heart of the program imo, everything is driven by time
* when time happens a few things occur.Snake moves, bird moves and the age increases
*/
	
	public void tick(){
		
		//for(GameObject jfk : OBCollection){
	//		System.out.println(jfk);
	//	}
		fixedAge();
		
		time++;		
		
		this.notifyObservers(getProxy());
	} 
	public void fixedAge(){
		
		for(GameObject spo : OBCollection){	
			if(spo instanceof Fixed){
				((Fixed) spo).setAge();
									}
						}
	}
	
	
		
	



	/**
	 * This returns the objectCollection
	 */
	public GameCollectionIrritable getCollection(){
		return OBCollection;
	}
	

	@Override
	public void addObserver(iObserver o) {
		myObserverList.add(o);
		
	}


	
	
public GameWorldProxy getProxy(){
	return new GameWorldProxy(this);
}
	


public Location getSnakeHead(){
	for(GameObject spo : OBCollection){	
		if(spo instanceof Snake){
			return ((Snake) spo).getHeadLoc();
		}
		
		
}
	
	return null;
}


public Location getWeaselLoc(){

	for(GameObject spo : OBCollection){
		if(spo instanceof Weasel){
		
			return ((Weasel) spo).getLocation();
		}
		
	}
	
	return null;
}








}

	

