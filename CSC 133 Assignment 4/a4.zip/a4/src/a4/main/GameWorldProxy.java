package a4.main;

import java.awt.Graphics;

import a4.GameObjects.GameObject;
import a4.GameObjects.IDrawable;
import a4.GameObjects.Location;

/**
 * The GameWorldProxy is the proxy for the GameWorld which will make it so the GameWorld is 
 * never actually messed with as long as an observer is looking at things.
 * 
 *
 */
public class GameWorldProxy implements iGameWorld{

	private GameWorld realGameWorld;
	
	
	public GameWorldProxy(GameWorld gw)
	{realGameWorld = gw;}



	@Override
	public int getScore() {
		return realGameWorld.getScore();
	}

	@Override
	public int getLives() {
		return realGameWorld.getLives();
	}
	
	@Override
	public int getTime() {
		return realGameWorld.getTime();
	}	
	
	public String getSound(){
		return realGameWorld.getSound();
	}
	
	public Location getSnakeHead(){
		return realGameWorld.getSnakeHead();
	}

	
	
	public GameCollectionIrritable getCollection(){
		return realGameWorld.OBCollection;
	}



	public Location getWeaselLoc(){
		return realGameWorld.getWeaselLoc();
	}
	
	

	



}