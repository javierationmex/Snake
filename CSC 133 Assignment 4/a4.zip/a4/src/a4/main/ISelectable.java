package a4.main;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.Point2D;

public interface ISelectable {

	public void setSelected(boolean yesNo);
	public boolean isSelected();
	public boolean contains(Point2D mouseWorldLoc);
	public void draw(Graphics2D g2d);
}
