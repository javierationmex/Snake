package a4.main;




import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.NoninvertibleTransformException;
import java.awt.geom.Point2D;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.border.LineBorder;

import a4.GameObjects.Bird;
import a4.GameObjects.GameObject;
import a4.GameObjects.IDrawable;
import a4.GameObjects.Movable;
import a4.GameObjects.Snake;
import a4.GameObjects.TotalBird;
/**
 * 
 * Mapview, currently this just throws the output to the console, it works similar to the scoreview where
 * it receives updates from the proxy which tell it that the map has changed.
 *
 */
@SuppressWarnings("serial")
public class MapView extends JPanel implements MouseWheelListener, iObserver, MouseListener, MouseMotionListener{
	AffineTransform worldToND, ndToScreen, theVTM, inverseVTM;
	private double winLeft = 0;
	private double winWidth =2000;
	private double winBottom = 0;
	private double winHeight = 2000;

	private Point2D mouseLoc;

	

	GameCollectionIrritable OBCollection;
	GameCollectionIrritable ThisCollection;
	
	 
	public MapView(){
		
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
		this.addMouseWheelListener(this);
		
		this.setBackground(Color.BLACK);
		mouseLoc = this.getMousePosition();
		this.zoomOut();
		this.zoomOut();
		
	}
	
	public int getWidth(){
		return (int)winWidth;
	}

	public int getHeight(){
		return (int)winHeight;
	}
		
	

	
	
/**
 * this takes values and then puts them inside the mapPanel
 */
	@Override
	public void update(GameWorldProxy p) {
		
	GameCollectionIrritable OBCollection = p.getCollection();
	ThisCollection = OBCollection;

	
	repaint();
	

	}
	
	
	public void paintComponent(Graphics g){
		
		super.paintComponent(g);	
		Graphics2D g2d = (Graphics2D) g;
		AffineTransform saveAT = g2d.getTransform();
	
		worldToND = buildWorldToNDXform(winLeft, winWidth, winBottom, winHeight);
		ndToScreen = buildNDToScreenXform(1200,1200);
		theVTM = (AffineTransform)ndToScreen.clone();
		theVTM.concatenate(worldToND);
		
		g2d.transform(theVTM);
		
		for(GameObject spo : ThisCollection){
				((IDrawable) spo).draw(g2d);
			}
			
			g2d.setTransform(saveAT);	
	}
		
	//}
	public AffineTransform buildWorldToNDXform(double wLeft, double wWidth, double wBottom, double wHeight){
		AffineTransform at = new AffineTransform();
		at.scale(1/wWidth, 1/wHeight);
		at.translate(-wLeft, -wBottom);
		return at;
	}
	
	public AffineTransform buildNDToScreenXform(int x, int y){
		AffineTransform at = new AffineTransform();
		at.translate(0, y);
		at.scale(x, -y);
		return at;
	}
	
	
	

	@Override
	public void mouseClicked(MouseEvent e) {
	try{
		inverseVTM = theVTM.createInverse();
	
		Point p = e.getPoint();
		Point2D mouseWorldLoc = inverseVTM.transform(p, null);
		
		
		for(GameObject spo : ThisCollection){
			if(spo instanceof ISelectable){
			
				if(((ISelectable) spo).contains(mouseWorldLoc) || e.isControlDown()){
					((ISelectable) spo).setSelected(true);
				
				}else if(!((ISelectable)spo).contains(mouseWorldLoc)){
						((ISelectable)spo).setSelected(false);}
				
			}
		this.repaint();
		}}catch(NoninvertibleTransformException ed)
			{
				System.out.println(ed);
			}
			
			
	}



	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		Point p = e.getPoint();
	
		
		for(GameObject spo : ThisCollection){
			if(spo instanceof ISelectable){
			
				if(((ISelectable) spo).contains(p) || e.isControlDown()){
					((ISelectable) spo).setSelected(true);
					repaint();
				}else if(!((ISelectable)spo).contains(p)){
					((ISelectable)spo).setSelected(false);}
		}}
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
	
		
		
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		

			Point2D mouseOldLoc;
			double x, y;
			try {
				inverseVTM = theVTM.createInverse();
				mouseOldLoc = mouseLoc;
				mouseLoc = inverseVTM.transform(e.getPoint(), null);
		
				 if (mouseLoc != null && mouseOldLoc != null)
				 {
					x = mouseOldLoc.getX() - mouseLoc.getX();
					y = mouseOldLoc.getY() - mouseLoc.getY();
					winLeft += x*.25;
					winWidth += y*.25;
					winBottom += x*.25;
					winHeight += y*.25;
					repaint();
				 
				}
				
				} catch (NoninvertibleTransformException ea)
				{
					System.out.println(ea);
				}
			
	}




	@Override
	public void mouseMoved(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseWheelMoved(MouseWheelEvent e) {
		/*
		 * this code works for sure
		 */
		
		if ( e.getWheelRotation() > 0 ) // zoom out
		{
			this.zoomOut();
			
		}
	
		else{	this.zoomIn();

		}
	}
	
	public void zoomIn()
	{
		double h = winHeight - winBottom;
		double w = winWidth - winLeft;
		winLeft += w*0.05;
		winWidth -= w*0.05;
		winBottom += h*0.05;
		winHeight -= h*0.05;
		this.repaint();
	}
	public void zoomOut()
	{
		double h = winHeight - winBottom;
		double w = winWidth - winLeft;
		winLeft -= w*0.05;
		winWidth += w*0.05;
		winBottom -= h*0.05;
		winHeight += h*0.05;
		this.repaint();	
	}




}				