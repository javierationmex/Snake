package a4.main;

import java.util.ArrayList;
/**
 * 
 * Observable interface, has an arraylist in it which is just a collection of the Observers
 * this will also notify each of the observers inside here when told by the gameWorld Proxy
 *
 */
public class Observerable extends Object{

	protected ArrayList<iObserver> myObserverList = new ArrayList<iObserver>();
	
	public void addObserver(iObserver obs) {
		myObserverList.add(obs);
		
	}
public void notifyObservers(GameWorldProxy p) {
	for(int i = 0; i<myObserverList.size(); i++){
		myObserverList.get(i).update(p);
	}

	}


}
