package a4.main;




import java.awt.Color;


import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
/**
 * 
 * Scoreview, this will send labels to the main display panel and
 * it will update score, time, lives and sound each time update is called.
 *
 */
public class ScoreView extends JPanel implements iObserver{
	//this neeeds to update EVERYTIME that update is called
	private JPanel displayPanel;
	
	private JLabel scoreLabel = new JLabel();
	private JLabel timeLabel = new JLabel();
	private JLabel livesLabel = new JLabel();
	private JLabel soundLabel = new JLabel();
	
	private int score;
	private int time;
	private int lives;
	private String sound;
	
	
	public ScoreView(){
		displayPanel = new JPanel();
		displayPanel.setBorder(new LineBorder(Color.red, 8));
		sound = "Off";
		lives = 3;
		setDisplayPanel();
	
	}
	
	
	
	
	
	public JPanel getPanel(){
		return displayPanel;
	}
	
	
	private void setDisplayPanel(){
		scoreLabel.setText(("Score: " + score));
		livesLabel.setText(("Lives: " + lives));
		timeLabel.setText("Time: " + time);
		soundLabel.setText("Sound: " + sound);
		
		
		displayPanel.add(scoreLabel);
		displayPanel.add(livesLabel);
		displayPanel.add(timeLabel);
		displayPanel.add(soundLabel);
		
		
		
	}
	
	
	
	public void update(GameWorldProxy p) {
	score = p.getScore();
	lives = p.getLives();
	time = p.getTime();
	sound = p.getSound();
	
	this.setDisplayPanel();
	}
//code here to output the score, objects, time and lives
	//these must register with gameworld which is our observable
	
	
	

}
