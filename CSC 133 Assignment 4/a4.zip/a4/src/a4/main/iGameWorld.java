package a4.main;





import java.awt.Graphics;

import a4.GameObjects.GameObject;
import a4.GameObjects.Location;
/**
 * iGameWorld interface, the prototypes listed here are the ones that the proxy has access to
 * 
 *
 */
public interface iGameWorld {
	
	
	public GameCollectionIrritable getCollection();
	public int getScore();
	public int getLives();
	public int getTime();
	public String getSound();
	public Location getSnakeHead();
	public Location getWeaselLoc();
	
	
	

}
