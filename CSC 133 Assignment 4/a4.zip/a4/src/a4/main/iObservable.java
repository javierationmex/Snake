package a4.main;


/**
 * the Observable interface, this is going to just provide the prototypes
 * for addObserver and notifyObservers
 * 
 *
 */
public interface iObservable {
	public void addObserver(iObserver o);
	public void notifyObservers(GameWorldProxy p);
}
