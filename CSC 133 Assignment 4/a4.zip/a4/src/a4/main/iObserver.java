package a4.main;

/**
 * the Observer interface, it provides update prototype
 * 
 */

public interface iObserver {
	public void update(GameWorldProxy p);
}
